<footer class="footer mt-auto">
    <div class="container-fluid">
        <p class="text-muted mb-0">&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?> | APOSTLE</p>
    </div>
</footer>
