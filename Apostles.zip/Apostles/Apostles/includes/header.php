<header class="main-header">
    <div class="position-relative search-form">
        <input type="text" id="globalSearch" class="form-control" placeholder="Search orders, products...">
        <i class="fas fa-search form-control-icon"></i>
    </div>
    
    <div class="d-flex align-items-center">
        <!-- Notification Bell -->
        <div class="dropdown me-3">
            <a href="#" class="position-relative text-dark" id="notificationDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-bell fa-lg"></i>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    3
                    <span class="visually-hidden">unread notifications</span>
                </span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end notification-dropdown" aria-labelledby="notificationDropdown" style="width: 300px; max-height: 400px; overflow-y: auto;">
                <li><h6 class="dropdown-header">Notifications</h6></li>
                <li><hr class="dropdown-divider"></li>
                <li>
                    <a class="dropdown-item d-flex align-items-center py-2" href="#">
                        <div class="me-3">
                            <div class="bg-primary rounded-circle p-2 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                <i class="fas fa-box text-white"></i>
                            </div>
                        </div>
                        <div>
                            <p class="mb-1 fw-bold">Low Stock Alert</p>
                            <p class="mb-0 small text-muted">Coffee Beans stock is running low (3 left)</p>
                            <small class="text-muted">2 hours ago</small>
                        </div>
                    </a>
                </li>
                <li><hr class="dropdown-divider"></li>
                <li>
                    <a class="dropdown-item d-flex align-items-center py-2" href="#">
                        <div class="me-3">
                            <div class="bg-success rounded-circle p-2 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                <i class="fas fa-shopping-cart text-white"></i>
                            </div>
                        </div>
                        <div>
                            <p class="mb-1 fw-bold">New Order</p>
                            <p class="mb-0 small text-muted">New order #1234 has been placed</p>
                            <small class="text-muted">5 hours ago</small>
                        </div>
                    </a>
                </li>
                <li><hr class="dropdown-divider"></li>
                <li>
                    <a class="dropdown-item d-flex align-items-center py-2" href="#">
                        <div class="me-3">
                            <div class="bg-warning rounded-circle p-2 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                <i class="fas fa-exclamation-triangle text-white"></i>
                            </div>
                        </div>
                        <div>
                            <p class="mb-1 fw-bold">Expiry Alert</p>
                            <p class="mb-0 small text-muted">5 products are about to expire</p>
                            <small class="text-muted">1 day ago</small>
                        </div>
                    </a>
                </li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-center" href="#">View all notifications</a></li>
            </ul>
        </div>
        
        <!-- User Profile -->
        <div class="user-dropdown dropdown">
            <a href="profile.php" class="dropdown-toggle text-decoration-none" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <img src="https://scontent.fcgy2-1.fna.fbcdn.net/v/t1.15752-9/483156597_1546510726032748_1316544022612528289_n.jpg?_nc_cat=100&ccb=1-7&_nc_sid=0024fc&_nc_eui2=AeE0mLOypOfzwWwCqiq-GyjUC9yXFe75T9EL3JcV7vlP0TrFvIUFwlyJ2POnxQwi40iL-ykX1FiIH0-isnAz8M-a&_nc_ohc=ahqzs3ASFKQQ7kNvwGmY5qz&_nc_oc=Adnbh6wi7aXgnwaDFP9RvZLnrHqPM2oRG3ByzfzABXtFoM7Vtiw4RQ_UPHvKGmWkz1I&_nc_ad=z-m&_nc_cid=0&_nc_zt=23&_nc_ht=scontent.fcgy2-1.fna&oh=03_Q7cD2QHf55bh2TGAvFW74YNs8j4hLb8wUmrA7gdv4_pQX9u7uw&oe=6852A29B"<?php echo urlencode($_SESSION['username']); ?>&background=random&color=fff&size=128" alt="User" class="user-avatar">
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i> Profile</a></li>
                <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i> Settings</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</header>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Global search functionality
    const globalSearch = document.getElementById('globalSearch');
    if (globalSearch) {
        globalSearch.addEventListener('keyup', function(e) {
            const searchTerm = this.value.toLowerCase().trim();
            
            // If on inventory page, filter products
            const productRows = document.querySelectorAll('.table tbody tr');
            if (productRows.length > 0) {
                productRows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    if (text.includes(searchTerm) || searchTerm === '') {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            }
            
            // If Enter key is pressed, redirect to search results
            if (e.key === 'Enter' && searchTerm !== '') {
                // Get current page
                const currentPage = window.location.pathname.split('/').pop();
                
                if (currentPage === 'inventory.php') {
                    // Already on inventory page, just filter
                } else if (currentPage === 'orders.php') {
                    // Already on orders page, just filter
                } else {
                    // Redirect to inventory page with search term
                    window.location.href = 'inventory.php?search=' + encodeURIComponent(searchTerm);
                }
            }
        });
        
        // Check if there's a search parameter in the URL
        const urlParams = new URLSearchParams(window.location.search);
        const searchParam = urlParams.get('search');
        if (searchParam) {
            globalSearch.value = searchParam;
            // Trigger the keyup event to filter results
            globalSearch.dispatchEvent(new Event('keyup'));
        }
    }
});
</script>
