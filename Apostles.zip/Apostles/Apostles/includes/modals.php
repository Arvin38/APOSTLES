<!-- Edit Product Modal -->
<div class="modal fade" id="editProductModal" tabindex="-1" aria-labelledby="editProductModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editProductModalLabel">Edit Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editProductForm" action="edit_product.php" method="post">
                    <input type="hidden" id="editProductId" name="productId">
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="editProductName" class="form-label">Product Name</label>
                            <input type="text" class="form-control" id="editProductName" name="productName" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="editSku" class="form-label">SKU</label>
                            <input type="text" class="form-control" id="editSku" name="sku" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="editCategory" class="form-label">Category</label>
                        <select class="form-select" id="editCategory" name="category" required>
                            <option value="">Select a product category</option>
                            <?php foreach ($categories as $category): ?>
                            <option value="<?php echo $category['id']; ?>"><?php echo $category['name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="editBuyingPrice" class="form-label">Buying Price</label>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" step="0.01" class="form-control" id="editBuyingPrice" name="buyingPrice" required>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="editSellingPrice" class="form-label">Selling Price</label>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" step="0.01" class="form-control" id="editSellingPrice" name="sellingPrice" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="editQuantity" class="form-label">Quantity</label>
                            <input type="number" class="form-control" id="editQuantity" name="quantity" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="editUnit" class="form-label">Unit</label>
                            <select class="form-select" id="editUnit" name="unit" required>
                                <option value="Pieces">Pieces</option>
                                <option value="Boxes">Boxes</option>
                                <option value="Kg">Kg</option>
                                <option value="Liters">Liters</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="editExpiryDate" class="form-label">Expiry Date</label>
                        <input type="date" class="form-control" id="editExpiryDate" name="expiryDate">
                    </div>
                    
                    <div class="mb-3">
                        <label for="editDescription" class="form-label">Description</label>
                        <textarea class="form-control" id="editDescription" name="description" rows="3"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="editProductForm" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
    </div>
</div>

<!-- Delete Product Confirmation Modal -->
<div class="modal fade" id="deleteProductModal" tabindex="-1" aria-labelledby="deleteProductModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteProductModalLabel">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this product? This action cannot be undone.</p>
                <form id="deleteProductForm" action="delete_product.php" method="post">
                    <input type="hidden" id="deleteProductId" name="productId">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="deleteProductForm" class="btn btn-danger">Delete</button>
            </div>
        </div>
    </div>
</div>

<!-- View Product Details Modal -->
<div class="modal fade" id="viewProductModal" tabindex="-1" aria-labelledby="viewProductModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewProductModalLabel">Product Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="text-center mb-4">
                    <img id="productImage" src="" alt="Product" class="img-fluid rounded" style="max-height: 200px;">
                </div>
                
                <dl class="row">
                    <dt class="col-sm-4">Product Name:</dt>
                    <dd class="col-sm-8" id="viewProductName"></dd>
                    
                    <dt class="col-sm-4">SKU:</dt>
                    <dd class="col-sm-8" id="viewSku"></dd>
                    
                    <dt class="col-sm-4">Category:</dt>
                    <dd class="col-sm-8" id="viewCategory"></dd>
                    
                    <dt class="col-sm-4">Selling Price:</dt>
                    <dd class="col-sm-8" id="viewPrice"></dd>
                    
                    <dt class="col-sm-4">Buying Price:</dt>
                    <dd class="col-sm-8" id="viewCostPrice"></dd>
                    
                    <dt class="col-sm-4">Quantity:</dt>
                    <dd class="col-sm-8" id="viewQuantity"></dd>
                    
                    <dt class="col-sm-4">Status:</dt>
                    <dd class="col-sm-8" id="viewStatus"></dd>
                    
                    <dt class="col-sm-4">Last Updated:</dt>
                    <dd class="col-sm-8" id="viewLastUpdate"></dd>
                </dl>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#editProductModal">Edit</button>
            </div>
        </div>
    </div>
</div>
