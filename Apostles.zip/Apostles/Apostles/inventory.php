<?php
session_start();
require_once 'config.php';
require_once 'data.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get products data
$products = getProducts();
$categories = getCategories();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory - Inventory Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="d-flex">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="content-wrapper">
            <?php include 'includes/header.php'; ?>
            
            <div class="container-fluid p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Inventory</h2>
                   
                </div>
                
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Overall Inventory</h5>
                        
                        <div class="categories-filter mt-3 mb-4">
                            <div class="d-flex flex-wrap gap-2">
                                <button class="btn btn-primary btn-sm rounded-pill active" data-category="all">All</button>
                                <button class="btn btn-light btn-sm rounded-pill" data-category="grains">Grains</button>
                                <button class="btn btn-light btn-sm rounded-pill" data-category="oil">Oil</button>
                                <button class="btn btn-light btn-sm rounded-pill" data-category="pasta">Pasta</button>
                                <button class="btn btn-light btn-sm rounded-pill" data-category="beverages">Beverages</button>
                                <button class="btn btn-light btn-sm rounded-pill" data-category="canned-goods">Canned Goods</button>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h6 class="mb-0">Products</h6>
                            <div class="d-flex gap-2">
                                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addProductModal">
                                    <i class="fas fa-plus"></i> Add Product
                                </button>
                                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#scanBarcodeModal">
                                    <i class="fas fa-barcode"></i> Scan Barcode
                                </button>
                                <div class="dropdown">
                                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="filterDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fas fa-filter"></i> Filters
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="filterDropdown">
                                        <li><a class="dropdown-item" href="#">All Products</a></li>
                                        <li><a class="dropdown-item" href="#">Low Stock</a></li>
                                        <li><a class="dropdown-item" href="#">Out of Stock</a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item" href="#">Price: Low to High</a></li>
                                        <li><a class="dropdown-item" href="#">Price: High to Low</a></li>
                                    </ul>
                                </div>
                                <button class="btn btn-outline-secondary" id="downloadInventory">
                                    <i class="fas fa-download"></i> Download all
                                </button>
                            </div>
                        </div>
                        
                        <div class="table-responsive mt-3">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Product Name</th>
                                        <th>Category</th>
                                        <th>SKU</th>
                                        <th>Price</th>
                                        <th class="d-none">Cost Price</th>
                                        <th>Quantity</th>
                                        <th>Expiry Date</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($products as $product): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" class="me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                                <?php echo $product['name']; ?>
                                            </div>
                                        </td>
                                        <td><?php echo $product['category']; ?></td>
                                        <td><?php echo $product['sku']; ?></td>
                                        <td>₱<?php echo number_format($product['price'], 2); ?></td>
                                        <td class="d-none">₱<?php echo number_format($product['cost_price'], 2); ?></td>
                                        <td><?php echo $product['quantity']; ?> <?php echo $product['unit']; ?></td>
                                        <td><?php echo date('m/d/Y', strtotime($product['last_update'])); ?></td>
                                        <td>
                                            <?php if ($product['quantity'] <= 0): ?>
                                                <span class="badge bg-danger">Out of Stock (0)</span>
                                            <?php elseif ($product['quantity'] <= 5): ?>
                                                <span class="badge bg-warning text-dark">Low Stock (<?php echo $product['quantity']; ?>)</span>
                                            <?php else: ?>
                                                <span class="badge bg-success">In Stock (<?php echo $product['quantity']; ?>)</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="#" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editProductModal" data-id="<?php echo $product['id']; ?>">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <a href="#" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteProductModal" data-id="<?php echo $product['id']; ?>">
                                                    <i class="fas fa-trash-alt"></i>
                                                </a>
                                                <a href="#" class="btn btn-sm btn-info text-white" data-bs-toggle="modal" data-bs-target="#viewProductModal" data-id="<?php echo $product['id']; ?>">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <nav aria-label="Page navigation">
                            <ul class="pagination justify-content-end" id="productPagination">
                                <li class="page-item">
                                    <a class="page-link" href="#" id="prevPage" tabindex="-1">Previous</a>
                                </li>
                                <li class="page-item active"><a class="page-link" href="#" data-page="1">1</a></li>
                                <li class="page-item"><a class="page-link" href="#" data-page="2">2</a></li>
                                <li class="page-item"><a class="page-link" href="#" data-page="3">3</a></li>
                                <li class="page-item">
                                    <a class="page-link" href="#" id="nextPage">Next</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
            
            <?php include 'includes/footer.php'; ?>
        </div>
    </div>

    <!-- Add Product Modal -->
    <div class="modal fade" id="addProductModal" tabindex="-1" aria-labelledby="addProductModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="addProductModalLabel">New Product</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" style="max-height: 80vh; overflow-y: auto;">
                    <form id="addProductForm" action="add_product.php" method="post" class="row g-2">
                        <div class="text-center mb-2 col-12">
                            <div class="product-image-upload border rounded p-2">
                                <div id="imagePreview" class="mb-1" style="width: 80px; height: 80px; margin: 0 auto; border: 1px dashed #ccc; display: flex; align-items: center; justify-content: center;">
                                    <i class="fas fa-image fa-2x text-muted"></i>
                                </div>
                                <small class="d-block text-muted">Drag image here</small>
                                <small class="d-block text-primary">Select file image</small>
                                <input type="file" id="productImage" name="productImage" class="form-control d-none">
                            </div>
                        </div>
                        
                        <div class="mb-2 col-12">
                            <label for="productName" class="form-label small mb-1">Product Name</label>
                            <input type="text" class="form-control form-control-sm" id="productName" name="productName" placeholder="Enter product name" required>
                        </div>
                        
                        <div class="mb-2 col-12">
                            <label for="sku" class="form-label small mb-1">Product ID</label>
                            <input type="text" class="form-control form-control-sm" id="sku" name="sku" placeholder="Enter product ID" required>
                        </div>
                        
                        <div class="mb-2 col-12">
                            <label for="category" class="form-label small mb-1">Category</label>
                            <select class="form-select form-select-sm" id="category" name="category" required>
                                <option value="">Select product category</option>
                                <option value="1">Grains</option>
                                <option value="2">Oil</option>
                                <option value="3">Pasta</option>
                                <option value="4">Beverages</option>
                                <option value="5">Canned Goods</option>
                            </select>
                        </div>
                        
                        <div class="mb-2 col-6">
                            <label for="buyingPrice" class="form-label small mb-1">Buying Price</label>
                            <div class="input-group input-group-sm">
                                <span class="input-group-text">₱</span>
                                <input type="number" step="0.01" class="form-control form-control-sm" id="buyingPrice" name="buyingPrice" placeholder="Price" required>
                            </div>
                        </div>
                        
                        <div class="mb-2 col-6">
                            <label for="quantity" class="form-label small mb-1">Quantity</label>
                            <input type="number" class="form-control form-control-sm" id="quantity" name="quantity" placeholder="Quantity" required>
                        </div>
                        
                        <div class="mb-2 col-6">
                            <label for="unit" class="form-label small mb-1">Unit</label>
                            <input type="text" class="form-control form-control-sm" id="unit" name="unit" placeholder="Unit" required>
                        </div>
                        
                        <div class="mb-2 col-6">
                            <label for="expiryDate" class="form-label small mb-1">Expiry Date</label>
                            <input type="date" class="form-control form-control-sm" id="expiryDate" name="expiryDate">
                        </div>
                        
                        <div class="mb-2 col-12">
                            <label for="thresholdValue" class="form-label small mb-1">Threshold Value</label>
                            <input type="number" class="form-control form-control-sm" id="thresholdValue" name="thresholdValue" placeholder="Stock threshold">
                        </div>
                        
                        <div class="text-end col-12 mt-3">
                            <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" form="addProductForm" class="btn btn-sm btn-primary">Add Product</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Product Modal -->
    <div class="modal fade" id="editProductModal" tabindex="-1" aria-labelledby="editProductModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="editProductModalLabel">Edit Product</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editProductForm" action="edit_product.php" method="post">
                        <input type="hidden" id="editProductId" name="productId">
                        
                        <div class="text-center mb-3">
                            <div class="product-image-upload border rounded p-3">
                                <div id="editImagePreview" class="mb-2" style="width: 100px; height: 100px; margin: 0 auto; border: 1px dashed #ccc; display: flex; align-items: center; justify-content: center;">
                                    <i class="fas fa-image fa-2x text-muted"></i>
                                </div>
                                <small class="d-block text-muted">Drag image here</small>
                                <small class="d-block text-primary">Select file image</small>
                                <input type="file" id="editProductImage" name="productImage" class="form-control d-none">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="editProductName" class="form-label">Product Name</label>
                            <input type="text" class="form-control" id="editProductName" name="productName" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="editSku" class="form-label">Product ID</label>
                            <input type="text" class="form-control" id="editSku" name="sku" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="editCategory" class="form-label">Category</label>
                            <select class="form-select" id="editCategory" name="category" required>
                                <option value="">Select product category</option>
                                <option value="1">Grains</option>
                                <option value="2">Oil</option>
                                <option value="3">Pasta</option>
                                <option value="4">Beverages</option>
                                <option value="5">Canned Goods</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="editBuyingPrice" class="form-label">Buying Price</label>
                            <div class="input-group">
                                <span class="input-group-text">₱</span>
                                <input type="number" step="0.01" class="form-control" id="editBuyingPrice" name="buyingPrice" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="editExpiryDate" class="form-label">Expiry Date</label>
                            <input type="date" class="form-control" id="editExpiryDate" name="expiryDate">
                        </div>
                        
                        <div class="mb-3">
                            <label for="editQuantity" class="form-label">Quantity</label>
                            <input type="number" class="form-control" id="editQuantity" name="quantity" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="editUnit" class="form-label">Unit</label>
                            <input type="text" class="form-control" id="editUnit" name="unit" required>
                        </div>
                        
                        <div class="text-end">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" form="editProductForm" class="btn btn-primary">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Delete Product Modal -->
    <div class="modal fade" id="deleteProductModal" tabindex="-1" aria-labelledby="deleteProductModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="deleteProductModalLabel">Confirm Delete</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-3">
                        <i class="fas fa-exclamation-triangle fa-3x text-warning"></i>
                        <h5 class="mt-3">Are you sure?</h5>
                        <p>Are you sure you want to delete this product? This action cannot be undone.</p>
                    </div>
                    <form id="deleteProductForm" action="delete_product.php" method="post">
                        <input type="hidden" id="deleteProductId" name="productId">
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="confirmDeleteBtn" class="btn btn-sm btn-danger">Delete</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- View Product Modal -->
    <div class="modal fade" id="viewProductModal" tabindex="-1" aria-labelledby="viewProductModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewProductModalLabel">Product Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <img id="productImage" src="assets/img/placeholder.jpg" alt="Product" class="img-fluid rounded" style="max-height: 200px;">
                    </div>
                    <h4 id="viewProductName" class="text-center mb-3">Product Name</h4>
                    
                    <div class="row mb-2">
                        <div class="col-5 text-muted">SKU:</div>
                        <div id="viewSku" class="col-7">BEV-001</div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-5 text-muted">Category:</div>
                        <div id="viewCategory" class="col-7">Beverages</div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-5 text-muted">Price:</div>
                        <div id="viewPrice" class="col-7">$15.99</div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-5 text-muted">Cost Price:</div>
                        <div id="viewCostPrice" class="col-7">$10.50</div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-5 text-muted">Quantity:</div>
                        <div id="viewQuantity" class="col-7">42 Kg</div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-5 text-muted">Status:</div>
                        <div id="viewStatus" class="col-7">In Stock</div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-5 text-muted">Last Update:</div>
                        <div id="viewLastUpdate" class="col-7">2023-06-15</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#editProductModal">Edit</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Scan Barcode Modal -->
    <div class="modal fade" id="scanBarcodeModal" tabindex="-1" aria-labelledby="scanBarcodeModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="scanBarcodeModalLabel">Scan Barcode</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-3">
                        <div id="scanner-container" class="mb-3 position-relative">
                            <div class="p-3 text-center bg-light rounded border mb-2">
                                <i class="fas fa-camera fa-3x text-muted"></i>
                                <p class="mt-3 mb-0 text-muted">Camera view will appear here</p>
                            </div>
                            <video id="scanner" style="width: 100%; max-height: 300px; border: 1px solid #ddd; border-radius: 4px; display: none;"></video>
                        </div>
                        <button id="start-scanner" class="btn btn-primary">
                            <i class="fas fa-camera"></i> Start Camera
                        </button>
                        <button id="stop-scanner" class="btn btn-secondary d-none">
                            <i class="fas fa-stop"></i> Stop Camera
                        </button>
                    </div>
                    <div class="mb-3">
                        <label for="barcode-input" class="form-label">Or enter barcode manually:</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-barcode"></i></span>
                            <input type="text" class="form-control" id="barcode-input" placeholder="Enter barcode...">
                            <button class="btn btn-outline-primary" type="button">Search</button>
                        </div>
                    </div>
                    <div id="scan-result" class="alert alert-info d-none">
                        <span id="scan-result-text"></span>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@ericblade/quagga2/dist/quagga.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script>
    // Function to update notification badge
function updateNotificationBadge(message) {
    // Get the notification badge
    const badge = document.querySelector('#notificationDropdown .badge');
    
    if (badge) {
        // Increment the count
        let count = parseInt(badge.textContent.trim()) || 0;
        count++;
        badge.textContent = count;
        
        // Add the new notification to the dropdown
        const dropdown = document.querySelector('.notification-dropdown');
        if (dropdown) {
            // Create a new notification
            const now = new Date();
            const timeString = now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
            
            // Create the notification HTML
            const notificationHTML = `
            <li><hr class="dropdown-divider"></li>
            <li>
                <a class="dropdown-item d-flex align-items-center py-2" href="#">
                    <div class="me-3">
                        <div class="bg-primary rounded-circle p-2 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                            <i class="fas fa-bell text-white"></i>
                        </div>
                    </div>
                    <div>
                        <p class="mb-1 fw-bold">Inventory Update</p>
                        <p class="mb-0 small text-muted">${message}</p>
                        <small class="text-muted">Just now</small>
                    </div>
                </a>
            </li>
            `;
            
            // Insert the notification before the "View all notifications" link
            const viewAllLi = dropdown.querySelector('li:last-child');
            if (viewAllLi) {
                viewAllLi.insertAdjacentHTML('beforebegin', notificationHTML);
            }
        }
    }
}

document.addEventListener('DOMContentLoaded', function() {
        // Category filter buttons functionality
        const categoryButtons = document.querySelectorAll('.categories-filter button');
        if (categoryButtons.length > 0) {
            categoryButtons.forEach(button => {
                button.addEventListener('click', function() {
                    // Remove active class from all buttons
                    categoryButtons.forEach(btn => btn.classList.remove('active'));
                    // Add active class to clicked button
                    this.classList.add('active');
                    
                    const category = this.getAttribute('data-category');
                    const productRows = document.querySelectorAll('.table tbody tr');
                    
                    productRows.forEach(row => {
                        const productCategory = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                        
                        if (category === 'all' || productCategory.toLowerCase().includes(category.replace('-', ' '))) {
                            row.style.display = '';
                        } else {
                            row.style.display = 'none';
                        }
                    });
                });
            });
        }
        
        // Download inventory functionality
        const downloadBtn = document.getElementById('downloadInventory');
        if (downloadBtn) {
            downloadBtn.addEventListener('click', function() {
                // Get table data
                const table = document.querySelector('.table');
                const rows = table.querySelectorAll('tbody tr:not([style*="display: none"])');
                
                // Create CSV content
                let csvContent = 'Product Name,Category,SKU,Price,Quantity,Last Update,Status\n';
                
                rows.forEach(row => {
                    const productName = row.querySelector('td:nth-child(1)').textContent.trim();
                    const category = row.querySelector('td:nth-child(2)').textContent.trim();
                    const sku = row.querySelector('td:nth-child(3)').textContent.trim();
                    const price = row.querySelector('td:nth-child(4)').textContent.trim();
                    const quantity = row.querySelector('td:nth-child(6)').textContent.trim();
                    const lastUpdate = row.querySelector('td:nth-child(7)').textContent.trim();
                    const status = row.querySelector('td:nth-child(8) .badge').textContent.trim();
                    
                    // Clean the data (remove commas from values to avoid CSV issues)
                    const cleanData = [
                        productName.replace(/,/g, ' '),
                        category.replace(/,/g, ' '),
                        sku.replace(/,/g, ' '),
                        price.replace(/,/g, ' '),
                        quantity.replace(/,/g, ' '),
                        lastUpdate.replace(/,/g, ' '),
                        status.replace(/,/g, ' ')
                    ];
                    
                    csvContent += cleanData.join(',') + '\n';
                });
                
                // Create download link
                const encodedUri = encodeURI('data:text/csv;charset=utf-8,' + csvContent);
                const link = document.createElement('a');
                link.setAttribute('href', encodedUri);
                link.setAttribute('download', 'inventory_' + new Date().toISOString().slice(0, 10) + '.csv');
                document.body.appendChild(link);
                
                // Trigger download
                link.click();
                document.body.removeChild(link);
            });
        }
        
        // Action buttons functionality
        const actionButtons = document.querySelectorAll('.table .btn-group a');
        if (actionButtons.length > 0) {
            actionButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    const action = this.getAttribute('data-bs-target');
                    const productId = this.getAttribute('data-id');
                    
                    if (action === '#editProductModal') {
                        console.log('Edit product:', productId);
                        // In a real app, we would load product data here
                        populateEditForm(productId);
                    } else if (action === '#deleteProductModal') {
                        console.log('Delete product:', productId);
                        document.getElementById('deleteProductId').value = productId;
                    } else if (action === '#viewProductModal') {
                        console.log('View product:', productId);
                        // In a real app, we would load product details here
                        populateViewDetails(productId);
                    }
                    
                    // Ensure tr has data-id for easier reference
                    const productRow = this.closest('tr');
                    if (productRow && !productRow.hasAttribute('data-id')) {
                        productRow.setAttribute('data-id', productId);
                    }
                });
            });
        }
        
        // Helper function to populate edit form with product data
        function populateEditForm(productId) {
            // In a real app, this would make an AJAX request to get product data
            // For demo, we'll use hardcoded data
            const productData = {
                1: { name: 'Coffee Beans', sku: 'BEV-001', category: 1, buyingPrice: 10.50, sellingPrice: 15.99, quantity: 42, unit: 'Kg' },
                2: { name: 'Rice', sku: 'GRN-002', category: 2, buyingPrice: 15.25, sellingPrice: 20.50, quantity: 3, unit: 'Kg' },
                3: { name: 'Office Supplies', sku: 'STA-003', category: 3, buyingPrice: 30.00, sellingPrice: 45.75, quantity: 18, unit: 'Boxes' },
                4: { name: 'Bottled Water', sku: 'BEV-004', category: 1, buyingPrice: 0.75, sellingPrice: 1.99, quantity: 120, unit: 'Pieces' },
                5: { name: 'Tea', sku: 'BEV-005', category: 1, buyingPrice: 8.00, sellingPrice: 12.50, quantity: 25, unit: 'Boxes' },
                6: { name: 'Flour', sku: 'BAK-006', category: 4, buyingPrice: 5.50, sellingPrice: 8.75, quantity: 0, unit: 'Kg' }
            };
            
            const product = productData[productId];
            if (product) {
                const form = document.getElementById('editProductForm');
                if (form) {
                    form.querySelector('#editProductName').value = product.name;
                    form.querySelector('#editSku').value = product.sku;
                    form.querySelector('#editCategory').value = product.category;
                    form.querySelector('#editBuyingPrice').value = product.buyingPrice;
                    form.querySelector('#editSellingPrice').value = product.sellingPrice;
                    form.querySelector('#editQuantity').value = product.quantity;
                    form.querySelector('#editUnit').value = product.unit;
                    form.querySelector('#editProductId').value = productId;
                }
            }
        }
        
        // Helper function to populate view details modal
        function populateViewDetails(productId) {
            // Similar to above, we'll use hardcoded data
            const productData = {
                1: { 
                    name: 'Coffee Beans', 
                    sku: 'BEV-001', 
                    category: 'Beverages', 
                    price: 15.99, 
                    cost_price: 10.50, 
                    quantity: 42, 
                    unit: 'Kg', 
                    last_update: '2023-06-15',
                    image: 'assets/img/pasta.jpg',
                    status: 'In Stock'
                },
                // Add more product data as needed
            };
            
            const product = productData[productId] || productData[1]; // Fallback to first product
            
            const viewModal = document.getElementById('viewProductModal');
            if (viewModal) {
                viewModal.querySelector('#viewProductName').textContent = product.name;
                viewModal.querySelector('#viewSku').textContent = product.sku;
                viewModal.querySelector('#viewCategory').textContent = product.category;
                viewModal.querySelector('#viewPrice').textContent = '$' + product.price;
                viewModal.querySelector('#viewCostPrice').textContent = '$' + product.cost_price;
                viewModal.querySelector('#viewQuantity').textContent = product.quantity + ' ' + product.unit;
                viewModal.querySelector('#viewStatus').textContent = product.status;
                viewModal.querySelector('#viewLastUpdate').textContent = product.last_update;
                
                const productImage = viewModal.querySelector('#productImage');
                if (productImage) {
                    productImage.src = product.image;
                    productImage.alt = product.name;
                }
            }
        }
        
        // Barcode scanner functionality
        const startScannerBtn = document.getElementById('start-scanner');
        const stopScannerBtn = document.getElementById('stop-scanner');
        const scanResult = document.getElementById('scan-result');
        const scanResultText = document.getElementById('scan-result-text');
        const scannerModal = document.getElementById('scanBarcodeModal');
        
        let scannerRunning = false;
        
        // Configure scanner behavior when modal is closed
        if (scannerModal) {
            scannerModal.addEventListener('hidden.bs.modal', function() {
                if (scannerRunning) {
                    Quagga.stop();
                    scannerRunning = false;
                    if (stopScannerBtn) {
                        stopScannerBtn.classList.add('d-none');
                    }
                    if (startScannerBtn) {
                        startScannerBtn.classList.remove('d-none');
                    }
                }
            });
        }
        
        if (startScannerBtn) {
            startScannerBtn.addEventListener('click', function() {
                if (typeof Quagga !== 'undefined') {
                    // Show the video element and hide the placeholder
                    document.querySelector('#scanner').style.display = 'block';
                    document.querySelector('#scanner-container .bg-light').style.display = 'none';
                    
                    initBarcodeScanner();
                    startScannerBtn.classList.add('d-none');
                    stopScannerBtn.classList.remove('d-none');
                } else {
                    alert('Barcode scanner library not loaded. Please try again later.');
                }
            });
        }
        
        if (stopScannerBtn) {
            stopScannerBtn.addEventListener('click', function() {
                if (scannerRunning) {
                    Quagga.stop();
                    scannerRunning = false;
                }
                
                // Hide the video element and show the placeholder
                document.querySelector('#scanner').style.display = 'none';
                document.querySelector('#scanner-container .bg-light').style.display = 'block';
                
                startScannerBtn.classList.remove('d-none');
                stopScannerBtn.classList.add('d-none');
            });
        }
        
        // Delete product functionality
        const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
        if (confirmDeleteBtn) {
            confirmDeleteBtn.addEventListener('click', function() {
                const productId = document.getElementById('deleteProductId').value;
                
                // Find the product row by data-id
                const productRow = document.querySelector(`.table tbody tr[data-id="${productId}"]`) || 
                                   document.querySelector(`.table tbody tr a[data-id="${productId}"]`).closest('tr');
                
                if (productRow) {
                    // Get product name for notification
                    const productName = productRow.querySelector('td:first-child').textContent.trim();
                    
                    // Remove the row
                    productRow.remove();
                    
                    // Close the modal
                    const modal = bootstrap.Modal.getInstance(document.getElementById('deleteProductModal'));
                    if (modal) {
                        modal.hide();
                    }
                    
                    // Show success notification
                    updateNotificationBadge(`Product "${productName}" was deleted`);
                    alert(`Product "${productName}" has been deleted successfully.`);
                }
            });
        }
        
        // Edit product form functionality
        const editProductForm = document.getElementById('editProductForm');
        if (editProductForm) {
            editProductForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Get form data
                const productId = document.getElementById('editProductId').value;
                const productName = document.getElementById('editProductName').value;
                const sku = document.getElementById('editSku').value;
                const category = document.getElementById('editCategory').options[document.getElementById('editCategory').selectedIndex].text;
                const buyingPrice = document.getElementById('editBuyingPrice').value;
                const expiryDate = document.getElementById('editExpiryDate').value;
                const quantity = document.getElementById('editQuantity').value;
                const unit = document.getElementById('editUnit').value;
                
                // Find the product row by data-id to update it
                const productRow = document.querySelector(`.table tbody tr[data-id="${productId}"]`) || 
                                  document.querySelector(`.table tbody tr a[data-id="${productId}"]`).closest('tr');
                
                if (productRow) {
                    // Get current product image
                    const currentImg = productRow.querySelector('td:first-child img').getAttribute('src');
                    
                    // Update row with new data
                    const cells = productRow.querySelectorAll('td');
                    
                    // Update product name and image
                    cells[0].innerHTML = `
                        <div class="d-flex align-items-center">
                            <img src="${currentImg}" alt="${productName}" class="me-2" style="width: 40px; height: 40px; object-fit: cover;">
                            ${productName}
                        </div>
                    `;
                    
                    // Update other cells
                    cells[1].textContent = category;
                    cells[2].textContent = sku;
                    cells[3].textContent = `₱${parseFloat(buyingPrice).toFixed(2)}`;
                    cells[5].textContent = `${quantity} ${unit}`;
                    cells[6].textContent = new Date().toLocaleDateString();
                    
                    // Update stock status
                    const qtyNum = parseInt(quantity);
                    if (qtyNum > 10) {
                        cells[7].innerHTML = `<span class="badge bg-success">In Stock (${quantity})</span>`;
                    } else if (qtyNum > 0) {
                        cells[7].innerHTML = `<span class="badge bg-warning text-dark">Low Stock (${quantity})</span>`;
                    } else {
                        cells[7].innerHTML = `<span class="badge bg-danger">Out of Stock</span>`;
                    }
                    
                    // Close the modal
                    const modal = bootstrap.Modal.getInstance(document.getElementById('editProductModal'));
                    if (modal) {
                        modal.hide();
                    }
                    
                    // Show success notification
                    updateNotificationBadge(`Product "${productName}" was updated`);
                    alert(`Product "${productName}" has been updated successfully.`);
                }
            });
            
            // Image preview functionality for edit form
            const editImagePreview = document.getElementById('editImagePreview');
            const editProductImage = document.getElementById('editProductImage');
            
            if (editImagePreview && editProductImage) {
                editImagePreview.addEventListener('click', function() {
                    editProductImage.click();
                });
                
                editProductImage.addEventListener('change', function() {
                    const file = this.files[0];
                    if (file) {
                        const reader = new FileReader();
                        reader.onload = function(e) {
                            editImagePreview.innerHTML = `<img src="${e.target.result}" style="max-width: 100%; max-height: 100%;" />`;
                        };
                        reader.readAsDataURL(file);
                    }
                });
            }
        }
        
        // Function to populate edit form with product data
        function populateEditForm(productId) {
            // In a real app, this would fetch product data from the server
            // For demo purposes, we'll use hardcoded sample data
            const productData = {
                1: { name: 'Creamy Latte Nescafe', sku: 'BEV-001', category: 4, buyingPrice: 15, quantity: 42, unit: 'Kg' },
                2: { name: 'Tuna', sku: 'CNG-002', category: 5, buyingPrice: 20, quantity: 3, unit: 'Kg' },
                3: { name: 'Del monte spaghetti', sku: 'PST-003', category: 3, buyingPrice: 140.00, quantity: 18, unit: 'Boxes' },
                4: { name: 'Bottled Water', sku: 'BEV-004', category: 1, buyingPrice: 0.75, sellingPrice: 1.99, quantity: 120, unit: 'Pieces' },
                5: { name: 'Tea', sku: 'BEV-005', category: 4, buyingPrice: 8.00, sellingPrice: 12.50, quantity: 25, unit: 'Boxes' },
                6: { name: 'Flour', sku: 'GRN-006', category: 1, buyingPrice: 8.50, quantity: 0, unit: 'Kg' }
            };
            
            // Handle "new" products added dynamically
            if (productId === 'new') {
                const row = document.querySelector('.table tbody tr a[data-id="new"]').closest('tr');
                const name = row.querySelector('td:nth-child(1)').textContent.trim();
                const category = row.querySelector('td:nth-child(2)').textContent.trim();
                const sku = row.querySelector('td:nth-child(3)').textContent.trim();
                const price = row.querySelector('td:nth-child(4)').textContent.replace('₱', '').trim();
                const quantity = row.querySelector('td:nth-child(6)').textContent.split(' ')[0].trim();
                const unit = row.querySelector('td:nth-child(6)').textContent.split(' ')[1].trim();
                
                // Create temp product data
                productData.new = {
                    name: name,
                    sku: sku,
                    category: getCategoryValue(category),
                    buyingPrice: price,
                    expiryDate: getTomorrowDate(),
                    quantity: quantity,
                    unit: unit
                };
            }
            
            const product = productData[productId];
            if (product) {
                document.getElementById('editProductName').value = product.name;
                document.getElementById('editSku').value = product.sku;
                document.getElementById('editCategory').value = product.category;
                document.getElementById('editBuyingPrice').value = product.buyingPrice;
                document.getElementById('editExpiryDate').value = product.expiryDate;
                document.getElementById('editQuantity').value = product.quantity;
                document.getElementById('editUnit').value = product.unit;
                document.getElementById('editProductId').value = productId;
                
                // Set image preview based on product name
                const imageName = product.name.toLowerCase().replace(/\s+/g, '_');
                const editImagePreview = document.getElementById('editImagePreview');
                if (editImagePreview) {
                    editImagePreview.innerHTML = `<img src="assets/img/${imageName}.jpg" style="width: 100px; height: 100px; object-fit: cover;" onerror="this.src='assets/img/product_placeholder.jpg';" />`;
                }
            }
        }
        
        // Helper function to get category value from category name
        function getCategoryValue(categoryName) {
            const categoryMap = {
                'Grains': 1,
                'Oil': 2,
                'Pasta': 3,
                'Beverages': 4,
                'Canned Goods': 5
            };
            return categoryMap[categoryName] || 1;
        }
        
        // Helper function to get tomorrow's date in YYYY-MM-DD format
        function getTomorrowDate() {
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            return tomorrow.toISOString().split('T')[0];
        }
        
        // Add product form functionality
        const addProductForm = document.getElementById('addProductForm');
        if (addProductForm) {
            // Image preview functionality
            const imagePreview = document.getElementById('imagePreview');
            const productImage = document.getElementById('productImage');
            
            // Make the image preview clickable to select a file
            if (imagePreview) {
                imagePreview.addEventListener('click', function() {
                    productImage.click();
                });
                
                // Update the image preview when a file is selected
                if (productImage) {
                    productImage.addEventListener('change', function() {
                        const file = this.files[0];
                        if (file) {
                            const reader = new FileReader();
                            reader.onload = function(e) {
                                imagePreview.innerHTML = `<img src="${e.target.result}" style="max-width: 100%; max-height: 100%;" />`;
                            };
                            reader.readAsDataURL(file);
                        }
                    });
                }
            }
            
            // Form submission
            addProductForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // In a real application, this would send the data to the server
                // For demo purposes, we'll just add the product to the table
                const productName = document.getElementById('productName').value;
                const sku = document.getElementById('sku').value;
                const category = document.getElementById('category').options[document.getElementById('category').selectedIndex].text;
                const buyingPrice = document.getElementById('buyingPrice').value;
                const quantity = document.getElementById('quantity').value;
                const unit = document.getElementById('unit').value;
                
                // Create a new row in the table
                const table = document.querySelector('.table tbody');
                if (table) {
                    const newRow = document.createElement('tr');
                    const imagePreviewSrc = imagePreview.querySelector('img')?.src || 'assets/img/placeholder.jpg';
                    
                    newRow.innerHTML = `
                        <td>
                            <div class="d-flex align-items-center">
                                <img src="${imagePreviewSrc}" alt="${productName}" class="me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                ${productName}
                            </div>
                        </td>
                        <td>${category}</td>
                        <td>${sku}</td>
                        <td>₱${parseFloat(buyingPrice).toFixed(2)}</td>
                        <td class="d-none">₱${(parseFloat(buyingPrice) * 0.7).toFixed(2)}</td>
                        <td>${quantity} ${unit}</td>
                        <td>${new Date().toLocaleDateString()}</td>
                        <td>
                            <span class="badge bg-success">In Stock (${quantity})</span>
                        </td>
                        <td>
                            <div class="btn-group">
                                <a href="#" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editProductModal" data-id="new">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="#" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteProductModal" data-id="new">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                                <a href="#" class="btn btn-sm btn-info text-white" data-bs-toggle="modal" data-bs-target="#viewProductModal" data-id="new">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </div>
                        </td>
                    `;
                    
                    table.prepend(newRow);
                    
                    // Reset the form
                    addProductForm.reset();
                    imagePreview.innerHTML = '<i class="fas fa-image fa-2x text-muted"></i>';
                    
                    // Close the modal
                    const modal = bootstrap.Modal.getInstance(document.getElementById('addProductModal'));
                    if (modal) {
                        modal.hide();
                    }
                    
                    // Show success message and update notification badge
                    updateNotificationBadge(`New product "${productName}" was added`);
                    alert('Product added successfully!');
                }
            });
        }
        
        // Pagination functionality
        const productPagination = document.getElementById('productPagination');
        if (productPagination) {
            const pageLinks = productPagination.querySelectorAll('.page-link[data-page]');
            const prevPageLink = document.getElementById('prevPage');
            const nextPageLink = document.getElementById('nextPage');
            let currentPage = 1;
            
            // Function to update active page
            function updateActivePage(page) {
                currentPage = page;
                
                // Update active class
                pageLinks.forEach(link => {
                    const linkPage = parseInt(link.getAttribute('data-page'));
                    link.parentElement.classList.toggle('active', linkPage === page);
                });
                
                // Update prev/next buttons
                prevPageLink.parentElement.classList.toggle('disabled', page === 1);
                nextPageLink.parentElement.classList.toggle('disabled', page === pageLinks.length);
                
                // In a real application, this would load the appropriate page of data
                // For demo purposes, we'll just log the current page
                console.log('Loading page', page);
            }
            
            // Add click event to page links
            pageLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const page = parseInt(this.getAttribute('data-page'));
                    updateActivePage(page);
                });
            });
            
            // Add click event to prev/next buttons
            if (prevPageLink) {
                prevPageLink.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (currentPage > 1) {
                        updateActivePage(currentPage - 1);
                    }
                });
            }
            
            if (nextPageLink) {
                nextPageLink.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (currentPage < pageLinks.length) {
                        updateActivePage(currentPage + 1);
                    }
                });
            }
        }
        
        function initBarcodeScanner() {
            Quagga.init({
                inputStream: {
                    name: "Live",
                    type: "LiveStream",
                    target: document.querySelector('#scanner'),
                    constraints: {
                        width: 640,
                        height: 480,
                        facingMode: "environment"
                    },
                },
                locator: {
                    patchSize: "medium",
                    halfSample: true
                },
                numOfWorkers: 4,
                decoder: {
                    readers: [
                        "code_128_reader",
                        "ean_reader",
                        "ean_8_reader",
                        "code_39_reader",
                        "code_39_vin_reader",
                        "codabar_reader",
                        "upc_reader",
                        "upc_e_reader",
                        "i2of5_reader"
                    ],
                    debug: {
                        showCanvas: true,
                        showPatches: true,
                        showFoundPatches: true,
                        showSkeleton: true,
                        showLabels: true,
                        showPatchLabels: true,
                        showRemainingPatchLabels: true,
                        boxFromPatches: {
                            showTransformed: true,
                            showTransformedBox: true,
                            showBB: true
                        }
                    }
                },
            }, function(err) {
                if (err) {
                    console.error(err);
                    scanResultText.textContent = 'Error initializing camera: ' + err;
                    scanResult.classList.remove('d-none');
                    scanResult.classList.remove('alert-success');
                    scanResult.classList.add('alert-danger');
                    return;
                }
                scannerRunning = true;
                Quagga.start();
                
                // Show initialization message
                scanResultText.textContent = 'Camera initialized. Scanning for barcodes...';
                scanResult.classList.remove('d-none');
                scanResult.classList.remove('alert-danger');
                scanResult.classList.add('alert-info');
            });
            
            Quagga.onDetected(function(result) {
                if (result && result.codeResult && result.codeResult.code) {
                    const code = result.codeResult.code;
                    scanResultText.textContent = 'Barcode detected: ' + code;
                    scanResult.classList.remove('d-none');
                    scanResult.classList.remove('alert-danger');
                    scanResult.classList.remove('alert-info');
                    scanResult.classList.add('alert-success');
                    
                    // Search for product with this barcode
                    // In a real app, we would make an AJAX request to search for the product
                    // For demo, we'll just display the code and automatically stop after 2 seconds
                    
                    // Play success sound
                    const successAudio = new Audio('data:audio/wav;base64,//uQRAAAAWMSLwUIYAAsYkXgoQwAEaYLWfkWgAI0wWs/ItAAAGDgYtAgAyN+QWaAAihwMWm4G8QQRDiMcCBcH3Cc+CDv/7xA4Tvh9Rz/y8QADBwMWgQAZG/ILNAARQ4GLTcDeIIIhxGOBAuD7hOfBB3/94gcJ3w+o5/5eIAIAAAVwWgQAVQ2ORaIQwEMAJiDg95G4nQL7mQVWI6GwRcfsZAcsKkJvxgxEjzFUgfHoSQ9Qq7KNwqHwuB13MA4a1q/DmBrHgPcmjiGoh//EwC5nGPEmS4RcfkVKOhJf+WOgoxJclFz3kgn//dBA+ya1GhurNn8zb//9NNutNuhz31f////9vt///z+IdAEAAAK4LQIAKobHItEIYCGAExBwe8jcToF9zIKrEdDYIuP2MgOWFSE34wYiR5iqQPj0JIeoVdlG4VD4XA67mAcNa1fhzA1jwHuTRxDUQ//iYBczjHiTJcIuPyKlHQkv/LHQUYkuSi57yQT//uggfZNajQ3Vm//Gtd//v//yH5BAEAAAEALAAAAAABAAEAQAIAAgkK');
                    successAudio.play();
                    
                    setTimeout(function() {
                        if (scannerRunning) {
                            Quagga.stop();
                            scannerRunning = false;
                            
                            if (stopScannerBtn) {
                                stopScannerBtn.classList.add('d-none');
                            }
                            if (startScannerBtn) {
                                startScannerBtn.classList.remove('d-none');
                            }
                            
                            // Close modal after a short delay
                            setTimeout(function() {
                                const bsModal = bootstrap.Modal.getInstance(scannerModal);
                                if (bsModal) {
                                    bsModal.hide();
                                }
                                
                                // Search for product
                                const searchInput = document.getElementById('globalSearch');
                                if (searchInput) {
                                    searchInput.value = code;
                                    searchInput.dispatchEvent(new Event('keyup'));
                                }
                            }, 1000);
                        }
                    }, 2000);
                }
            });
            
            Quagga.onProcessed(function(result) {
                const drawingCtx = Quagga.canvas.ctx.overlay;
                const drawingCanvas = Quagga.canvas.dom.overlay;
                
                if (result) {
                    if (result.boxes) {
                        drawingCtx.clearRect(0, 0, parseInt(drawingCanvas.getAttribute("width")), parseInt(drawingCanvas.getAttribute("height")));
                        result.boxes.filter(function(box) {
                            return box !== result.box;
                        }).forEach(function(box) {
                            Quagga.ImageDebug.drawPath(box, { x: 0, y: 1 }, drawingCtx, { color: "green", lineWidth: 2 });
                        });
                    }
                    
                    if (result.box) {
                        Quagga.ImageDebug.drawPath(result.box, { x: 0, y: 1 }, drawingCtx, { color: "#00F", lineWidth: 2 });
                    }
                    
                    if (result.codeResult && result.codeResult.code) {
                        Quagga.ImageDebug.drawPath(result.line, { x: 'x', y: 'y' }, drawingCtx, { color: 'red', lineWidth: 3 });
                    }
                }
            });
        }
    });
    </script>
</body>
</html>
