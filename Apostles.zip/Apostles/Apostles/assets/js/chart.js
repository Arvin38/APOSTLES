/**
 * Chart.js configurations
 */
document.addEventListener('DOMContentLoaded', function() {
    // Sales Chart
    const salesChartCanvas = document.getElementById('salesChart');
    if (salesChartCanvas) {
        const salesData = {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [
                {
                    label: 'Sales',
                    data: [12000, 19000, 15000, 17000, 14000, 20000, 16000, 15000, 21000, 18000, 22000, 24000],
                    backgroundColor: 'rgba(90, 90, 243, 0.2)',
                    borderColor: 'rgba(90, 90, 243, 1)',
                    borderWidth: 2
                },
                {
                    label: 'Purchases',
                    data: [8000, 12000, 10000, 9500, 8200, 14000, 11000, 10000, 13000, 11000, 14000, 15000],
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 2
                }
            ]
        };
        
        new Chart(salesChartCanvas, {
            type: 'bar',
            data: salesData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            display: true,
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                }
            }
        });
    }
    
    // Product Categories Pie Chart
    const categoriesChartCanvas = document.getElementById('categoriesChart');
    if (categoriesChartCanvas) {
        const categoriesData = {
            labels: ['Beverages', 'Grains', 'Stationery', 'Baking', 'Canned Goods', 'Dairy', 'Produce'],
            datasets: [{
                data: [25, 15, 20, 10, 12, 8, 10],
                backgroundColor: [
                    'rgba(90, 90, 243, 0.7)',
                    'rgba(75, 192, 192, 0.7)',
                    'rgba(255, 205, 86, 0.7)',
                    'rgba(255, 99, 132, 0.7)',
                    'rgba(153, 102, 255, 0.7)',
                    'rgba(54, 162, 235, 0.7)',
                    'rgba(255, 159, 64, 0.7)'
                ],
                borderWidth: 1
            }]
        };
        
        new Chart(categoriesChartCanvas, {
            type: 'pie',
            data: categoriesData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right'
                    }
                }
            }
        });
    }
    
    // Revenue Trends Line Chart
    const trendChartCanvas = document.getElementById('trendChart');
    if (trendChartCanvas) {
        const trendData = {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'Revenue',
                data: [5000, 7000, 6500, 8000, 7500, 9000, 8500, 10000, 9500, 11000, 10500, 12000],
                fill: false,
                borderColor: 'rgba(90, 90, 243, 1)',
                tension: 0.1
            }]
        };
        
        new Chart(trendChartCanvas, {
            type: 'line',
            data: trendData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }
});
