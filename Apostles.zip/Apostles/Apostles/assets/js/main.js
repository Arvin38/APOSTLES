/**
 * Main JavaScript file
 */
document.addEventListener('DOMContentLoaded', function() {
    // Toggle sidebar on mobile
    const sidebarToggle = document.getElementById('sidebarToggle');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
            document.querySelector('.content-wrapper').classList.toggle('active');
        });
    }
    
    // Initialize popovers
    const popoverTriggerList = document.querySelectorAll('[data-bs-toggle="popover"]');
    const popoverList = [...popoverTriggerList].map(popoverTriggerEl => new bootstrap.Popover(popoverTriggerEl));
    
    // Initialize tooltips
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
    
    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
    
    // Product Search functionality
    const searchInput = document.getElementById('productSearch');
    if (searchInput) {
        searchInput.addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            const productRows = document.querySelectorAll('tbody tr');
            
            productRows.forEach(function(row) {
                const productName = row.querySelector('td:first-child').textContent.toLowerCase();
                const category = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                const sku = row.querySelector('td:nth-child(3)').textContent.toLowerCase();
                
                if (productName.includes(searchTerm) || category.includes(searchTerm) || sku.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
    
    // Product edit modal
    const editProductModal = document.getElementById('editProductModal');
    if (editProductModal) {
        editProductModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            const productId = button.getAttribute('data-id');
            
            // In a real application, fetch product details via AJAX
            // For demo, we'll use dummy data
            const productData = {
                1: { name: 'Coffee Beans', sku: 'BEV-001', category: 1, buyingPrice: 10.50, sellingPrice: 15.99, quantity: 42, unit: 'Kg' },
                2: { name: 'Rice', sku: 'GRN-002', category: 2, buyingPrice: 15.25, sellingPrice: 20.50, quantity: 3, unit: 'Kg' },
                3: { name: 'Office Supplies', sku: 'STA-003', category: 3, buyingPrice: 30.00, sellingPrice: 45.75, quantity: 18, unit: 'Boxes' },
                4: { name: 'Bottled Water', sku: 'BEV-004', category: 1, buyingPrice: 0.75, sellingPrice: 1.99, quantity: 120, unit: 'Pieces' },
                5: { name: 'Tea', sku: 'BEV-005', category: 1, buyingPrice: 8.00, sellingPrice: 12.50, quantity: 25, unit: 'Boxes' },
                6: { name: 'Flour', sku: 'BAK-006', category: 4, buyingPrice: 5.50, sellingPrice: 8.75, quantity: 0, unit: 'Kg' }
            };
            
            const product = productData[productId];
            
            // Update modal form fields with product data
            editProductModal.querySelector('.modal-title').textContent = 'Edit Product: ' + product.name;
            editProductModal.querySelector('#editProductName').value = product.name;
            editProductModal.querySelector('#editSku').value = product.sku;
            editProductModal.querySelector('#editCategory').value = product.category;
            editProductModal.querySelector('#editBuyingPrice').value = product.buyingPrice;
            editProductModal.querySelector('#editSellingPrice').value = product.sellingPrice;
            editProductModal.querySelector('#editQuantity').value = product.quantity;
            editProductModal.querySelector('#editUnit').value = product.unit;
            
            // Set product ID in hidden field
            editProductModal.querySelector('#editProductId').value = productId;
        });
    }
    
    // Profile picture upload
    const profilePictureInput = document.getElementById('profilePicture');
    if (profilePictureInput) {
        profilePictureInput.addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    document.querySelector('.avatar-preview').src = e.target.result;
                };
                
                reader.readAsDataURL(file);
            }
        });
    }
});
