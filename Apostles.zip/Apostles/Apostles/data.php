<?php
/**
 * Data Module
 * Handles data operations for products, inventory, sales, etc.
 */

/**
 * Get sales data for dashboard
 * 
 * @return array Sales statistics
 */
function getSalesData() {
    // In real application, fetch from database
    // Sample data for demonstration
    return [
        'totalSales' => 1000,
        'cost' => 10000,
        'revenue' => 1234,
        'orders' => 0,
        'avg' => 39.78,
        'profit' => 100000
    ];
}

/**
 * Get inventory summary for dashboard
 * 
 * @return array Inventory statistics
 */
function getInventorySummary() {
    // In real application, calculate from database
    return [
        'totalProducts' => 95,
        'totalCategories' => 8,
        'lowStock' => 12,
        'outOfStock' => 3
    ];
}

/**
 * Get product summary for dashboard
 * 
 * @return array List of products for dashboard
 */
function getProductSummary() {
    // In real application, fetch from database
    return [
        [
            'id' => 1,
            'name' => 'Creamy Latte Nescafe',
            'image' => '',
            'price' => 15,
            'quantity' => 42
        ],
        [
            'id' => 2,
            'name' => 'Tuna',
            'image' => '',
            'price' => 20,
            'quantity' => 3
        ],
        [
            'id' => 3,
            'name' => 'Del monte spaghetti',
            'image' => '',
            'price' => 140,
            'quantity' => 18
        ]
    ];
}

/**
 * Get all products
 * 
 * @return array List of products
 */
function getProducts() {
    // In real application, fetch from database with pagination
    return [
        [
             'id' => 1,
            'name' => 'Creamy Latte Nescafe',
            'image' => 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUSEhQVFhUVFxsVFRUXGBUYFxcWFRcYFxUYFRcYHSggGBolGxUXITEhJiktLi4uGB8zODMuNygtLisBCgoKDg0OGxAQGy0lICUvLS0tLS0tLS0vLS0tNS0tLS0tKy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABAUDBgcCAQj/xABHEAABAwEFBQQHBQYEBAcAAAABAAIDEQQFEiExBkFRYXETIjKRB1JigZLB8CNCobHRFHKCotLhFRZzsjNDU8IkNURjk7Px/8QAGQEBAAMBAQAAAAAAAAAAAAAAAAECAwQF/8QAJxEAAgIBAwQCAgMBAAAAAAAAAAECEQMSITETQVFhBDIUInGB0bH/2gAMAwEAAhEDEQA/AO4oiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgC+YhxXifwnoqOOaoJypu6ACpKyyZdDovGGov8Q4piHEKgMxArQV1p8VAfL8CtO9Jm277tjiEQjdPKahrwSGxjVxAIOeQ1VI5rdJFnjo6hiHEJiHEL83xemK31FWWWn+nJy/9xbLYPSPaJW1Ag+B39a11S8FdKO14hxCYhxC4+dubVwh+B3P215/z1auEPwO/rTVLwNKOxYhxCYhxC47/nu1cIfgdy9tfRt3auEPwO5+2lvwNKOw4hxCYhxC5GNubVwh+B39S9s22tPCH4XcvaU2xpR1nEOITEOK5YNsbRwi+F3A+0sg2vn4RfC7j+8o1PwNKOn4hxCYhxC5iza2bhF8J5c16k2qn1Ai+E8/aTVLwNKOmYhxCYhxC57de0z5DheGV3UBHXer2C1k608lR5WnTRZYrVmy4hxCAqjc88tf1p9clY3fv9ymOS3REoUrJiIi1MwiIgCIiAIiIAiIgMc/hPRa+aAAaDxHoKU38c+gK2CfwnoqE656Vpv8LBn/ALX/ABLl+RyjbFwemNqc8gM3cqjOue4YR5r80ekW/wA228Jpvutd2Uf7kZIFM95qfev0BtneP7Nd9qm0c2M0/feaD+Z4X542CuuO1XhZrPMCY5H0eASCRhcdRmMwpwrlibKMOU+7bxdE6u7eup+lL0WQWazG12Fr2iI/bRFznjszljYTVwLTSoJpSpypnUehrY6yXiLUbW1zuy7PBhe5tMWPF4Tn4Qt6K6tjDYbzje2uID3hSf2hnrt8x+q9ifZb/p2zzl/qXoT7Lf8ATtnnL/UpIsw9uz1m+Y/VfWzN9ZvmOfNTrJBs5KCYrPeDwDQlgncAeBwuyTHs03/l20EZGplqONe/kgsjGdvrN8xx6r3FO31h5jlzU+GHZ97cbYLwLNcYE5bQe1ioskT9ntzLX8Un9aE2RBOPWHmODufNfTaRXxDzHHqrJstwbmWrzk/qXrtLg9S1eb/6lAKttqHEeY5c1Ms0oeaYhpxHPnzCrNoLRd5AbYoZmmvekleaU4NZiOvE000Uaw2hkYPiLjyyHKpVJtpbHT8bHCc11HUe5czWlsMgo8VFDqBv68lu1z20PAINQ4ZUP9+K49eoxux8foLb9gLZ3Cz1DUdD/cfisM7cYKRKUHkko8djp9Mq8Pyz+v4VYXUcj9cVDs+Y6j6/I+ak3P8Ae6/qmJ/sjGf1ZZIiLsOcIiIAiIgCIiAIiIDHP4T0WpXoH4G4a1DmBxaSKhxaDo3TJ1eq22fwnotYvGDtAGinjjdXhhL3DQ8QPNcuf7I2xcGnemu3Bt2ujJoZZWADiGvxH/aFyr0U/wDm9j/1D/setz9Pcvcso4ukPlh/VaV6KnAXtYySAO0OZyHgcp+K7x3/ACMnLO82PaRrr2td1T0cySNkkIdmDWFomiodxb36cnqo9F+zbrutd6WY1wARPicfvRP7bAeooWnm0rm/pbvN0N+OtEDgHxiF7HA1GJsbTnTUbiN4JXc9m9q7JbrOLTHJGHujpI0uaHxkAkseDnQEmh0NajVdBkah6HJZmXDI6zND5mvmMTHaOkAGBpzGRNN4WrekDaG+3WQw3lZIILPNJGwvZ46tcJQG0mdTKInMblaehW9mS3ZaLvbaGwWnFJ2RrRwEjBhkYKjFhfWoHAcVX7SbHXpHA6W8bcyeKNzXMi7SR5c4nAHAOaACGvdxyqhPc6TtPHb4IYRc8cBiYwgx0FaUb2fZglraUrXOui5ts5HLeV+xuvGBrHxx4pIjG5rXGIUjxMeTveHakHCNy2nZ3Ze9LO+J1nt8LrLVpewlzm4MqhrS0gZV0cM1IvzaWzR31Znh7C1sL4ZpAatZjNWAkZZOArwD89EBV7cekW2WW3S2aziERw4G95hcXF0bJDUhwoO+BQcFA9Et3tktU1tloGWdpfXcHyYiSOjQ/wAwrja/0eyWy1SWuCaDs5cLiXOd3cMbWVBaCHCjAdRqvWy0lnsdzyvnBkbNI9rmscA57C7sW4cwQC1uLXQoO2xn2/DLwuyG8I2kFlHEakMecEjT+68NNfZKsNiZZ2XKx1mYHzAyYGO0J7d1a5jdXeE2RttitVjtFls7HQx0cwtkeCftmnvNJcTrX3quuS2OjuB/ZvwSxF4dhd3mONoJ3aZO8igIl93reT3WVltgjijda4C0t1LmyAgZSO3V3LcdqLdeMcjBYoI5WFtXF2odU5D7Ru6i5EL8nfJE6eWSRsUrJQHOLs2OByB30BC6ptDZLRbezlu+2Na3CQ4CRwaamoPcBz1BBHBCTl+11rnntD3WljWStoxzW6DCMvvHjxXzZF2GanrAjyz+SmX1c0jJ5GTTxvkDRI95cTiJByqcych5hQ7gH2zTz+RWOaNwaNcb/ZHYLpfWNh5fMD9VOunV/Ufkq64v+Cz63qzuvV/ULDDzEnL3LBERdxzBERAEREAREQBERAY7R4T0VBiBrn6pGevez3+2PNX8/hPRa6xtO7voWDXLIYTX+BnxLmz8o2x8M5R6d46xWd/qyPb8QrxPqLjq776X7D2tgkcBnGWzDoHEO/lcfJcEaFT4j/Rrw3/pbIty4uPZ19ojknc9kFmiIEk8mLDidpGxrQXSSEZ4QMhqRUJtPcTLKYjHaIrRHNH2jHsDmkCpFJGOzYag5Hgtw2xsbxct0ss7HOif2kkpaC6s7sOHERv70oHSm5bD6NrDJZm2exStYJppXWySN7I3PgszIwO8HAlj5XBgpqANxXTZlZxWq2fZsjsyTroujzdlYWw218TxabbaJJ3Qxwh8r2hx7OyAuFIW95pfTvkginC12fuZ0cllayJkX7VittsdgaR9s4ujsjMYIDQKtwDPIu3I2TZyxsYLt2f4qSAF0u0MDILTLNC3Ha7cG2aNzQKhuFsJcBmGd3ERlWlPvKyvExPmvBkMLXvjszYnkMBJllGCNrKDutbQk03nPJoUWDkYhABcaUUpl1ONkfbi5rWCUQsaQcUjiKuwkZAAceB9+93zOyCOyXk8NwxWbDhFB21pAdHHGABmKl7nHc1i1raOyzC77sgjikfjZJapMEb3DtJnBzRRoNMnuy4KbBrLXDfT3q1sdikfG+ZjaxxYRI8EUbjNG1zqangt32ZuR8TrvhjaGiZgtNslcxrsYcCY7M1zwRSjXAtGdAXbl7vOSeOyWmUQNLrVbHnA+MOayzwsJjc9pyblGHCu8g70sGm2mwyRNjdI0tErccZJHebxFDl71jbRdLtV3h05iljabPYbM0tc6OrpHsYDSo7z4xiBLWjWgOtFQS2+GbsJJwexiqxr3t7N1qe4hxq2IHDAym4GlQNSaTYs1UBWuzbKzN95/AqRtlMx07ezFmDOzGH9n8NCT48h3vdpRZtibMXyk8BT3uNPyqs8rqDL4/sjp91R4YmD2R+OanXWPF1/LJY2CgA+vrVZrBq4cKfNZYl+yE3dk1ERdZgEREAREQBERAEREBjtHhPRa6dx0xChPB7QKHTgAf4FsVo8J6LXnN1ad9DXLXLC8CulR+Y3Lmz8o2xlbfFkbK18bh3ZGua4cn4g4abjiHuC/M9uu58EskD/ABRvLD7jkehFD71+orSK04jUc9CPfl7w3iuXelbZqrm22MZEBk1PJj/+0/wrDHLRP0/+mjVr+DQLs2kttmjMUFpmjjJrga4gAnUt9X3UUGz3paIpTPHNK2V1Q6UPdjIdrV1amqkusqwiyFzmsb4nODRuzcaDM6ZldqZlR6s20ttijMUdqnbGSSWCRwFXGrjrlUkk9TxUm59pbS18LXWiUthyhGN1I8qdwVyyy6ZKY3Ye0ukkjZgpEaSveXRNY4NxvaWyAPNG1dUNoWtJGisLH6PCCe2kOJmboYwA54JtAaIZHZOP/hnONW5NI1zoI2Jkt5TOLHOlkdgJewlziWuccRc3PIk51WWzXmY5nOmfOY5q9uI5ML5AQaYnHXvGufE8VbWV93Rt7EzRSNIYxrw+rnuYbSwyuazvxjKMkVIJLcqarmt1kbCztGY5GuD3ARNc49nNjwh79A5jWig9uuoUA1XbG+JLXM2OOPDBZ4S6OJpqI4xnI9xObnHe5G3/AHlFFE0Wm0NifHWINkJHZtLmaNNWgdm4UNDRp3KZfO1MIs72tikbJNZ+xlLezZHj7OzMrhFatBgkoDoJnUoXZQru2/bDDHC2zlzRE2KSsmEPDYpmUFGmjS60PcfcMtVIDbZbmss0mOfA2v7KcTjhphbWMDwg9o1oO8Ggqsk9qtQZgkklLJQ20ubjLmuEmbJHgE5nDXvZ5A8FYM9IdTiFl31bWdxp9rNMCKx6h0rSDu7FmVBhEqz7ZQNiJEQxOwgwAvLezHYRujc40YWdhZsDe6SO2cKeJz5BVx7QWgPbJ+0S9o1uFrjI7EGHPCCTpvovdrtssjy6Zz3PGRLyS4U3Z6U4K1h22Y6rZY5Hsc4l1TG5xaXxdwZABoijeKby/M17yoLdbjLLJKTUvcXE0a0mprUhuQPH56oCSx66l6O7vwwiQjN5qOmjfmfeua7O3a60zMjbvOZ4NHiPl8l3WxwCNga0UAAAHAAUH4fNYZnwi8PJKZmRyWS7Rm93E/lVYmDMDecz0Uuy6kfW9Ma3RWXBIREXSZBERAEREAREQBERAYrT4XdFTvbiGXiGnkKg56FXFp8Duipwd4+fAclhl5NIcEOY5/hQ+/unPXhxWGazte1zHgOY8EOB0IOv9/PjSXa2VNRwoRxFSvDefnw6/wBXnTVc0o7UapnJtotjnWd5ABcw5sdy4H2h/danbLuwnNtRvHEbwv0S6Jj2mORtQd3zH101AWnbU7KANLm5t3O/VWjkceSaUjlt7bTWh7OyaSyMNLAHOMsmAtlYWulfm4YZ3gZCgw00Wt3pbZpzWaWSQ1Lu+5zqFxq4gE0FTwWyXtduEla9aYl0xlZm40VrSWmoyKvbqvmhAdr+axXRs5aLVV0TKRg0dM84Ymnhi+8fZaCeS3C5dioGGrmm0v8AaqyEHXwg4ne80PBWuuSCJJcRtoP7O0uecy1oJqeOXhKwWP0XWn/1M1ns3svfjk+BlR+K6xctgnAEeUbBoyNoYwDoAArS27MskFXDvDf8is+rHtuTokcysfo2sTcnXk4n2YQBXlVxU1/oxs5H2N4Z7u0iy8w4LdG7ONb90fgskd17sNOiz/Kj4ZfoS8nLb42AttmBeGtnjGr4DjIHEspi8gVWXFdclpdRgJaDQkcfVHNdmjuhzZA5krmCveLdVashZGS+gOdTIGgGp1MgG/2wOtFos0XwVcJLkrtkNnW2RlTTtHeM+qBowfPn0WxtO8+5YYu9n93WqkxMrnuGg+a51cnZZ7IyQNpmdSs1j1d9cVHina5xDXNJae8AQSOoGik2UZu+uK6IcoylwSURFuZhERAEREAREQBERAYrV4HdFr7Th+hwHJbBavA7oteDvr3DmubPyjXHwJ3Zgj6zK9MzzHl+nAqJaiQRT6zPNe4Za6eSonZZokGPLLMcOHSmnuy5DVeBKRUeIHUHhvqN45hZmPrrqvT2A6ivMaqssd8BM0vaDZBk9XQEMcfuGpaeh1H1oqGwbAsh+1tre0dXuWZhJaeDpnt+77I137wulmLB3h3nHusGhrz/AAz/AEXhgIGCudavdvJ/TgOSiN4o2/6Rf7uka3ZLldOW9pRrGijI2ANjY3c1jRkB0Wz2O7Y4x3QBTevjJABRq941lLLq5NlCuCQHgL020KFWqyNYeCqpy7EuK7mQz9F5MnReBGeCBqrciaRkEdeCxOjc01p/+LI0UUqF4ORWiSlsyjbRTl/YHG0F0RzcwEDC7i2uQHFWYsUkuc7sLT/yoyaEe3Jq7oKBYrVBSo3HJU47eUCIO+zaKEVLa65PI7zhpQCmmdV0Yn2fJlNd0YLwhxW2N1gOJ7HhswZlGxoHeDn0w7s48zmCACKrbrmtfa4zva5zHDPJzHFrhmBvHBVt03Y2PvVqYxRoADWNqAaMYMgFN2d8Mn+tL/8AfItlyjF8FuiItjMIiIAiIgCIiAIiIDFa/A7oqGSEjiR7+AV9ah3HdFoGzO1hmYe1ZQtNMqnKgofCKrnzVe5tjTptFlbXUI+t5Xhhqs9uLH0LCPonUKLgI6cVnpdE2S2Ska5qTHLzWl27avs5mxhrCwx9piLu9Srq5dADrv5q4ue+orSHYD3m0xN5HQjiMj5KursXeNpW0XU8+fNrRTq8uFfJpUZhqsUxoTzA/Au/Ve4XUFVnneqdejTEqieois4OVSo8QzWQsJK51sjbYkwTclNYoUMSlsC3x33McldjLgXx0Y4e9e2r1iXRSMbZHMaxPyKkOfxUTHicsZ0uDWFme05tVNc1e0dwNfMEf3VnaJV7umzigPH55q8Vcir2iZYsg/qfwaB8l6uFtGHm5zvike75qROA1hP1nkvN1swjDwDR+C6IqmjBu0yciItjMIiIAiIgCIiAIiIDFafCei4ls3AWNc9xpj8LThqG0BJOe8503CnNdttXgd0XC7nkfV2Zw9eTfbXJ8nsdXx3s0Xs1po4EGh5dTwWe03k90Mja5ljhXfmM/fRVVrkzGf4+07mVhntRYwngsIydGrSuzW7ztBMkLxnSra6gA4GkVG4tkdlkBTyu9hpiLWxvrte06ZBrcQrlU5gdK81rt6SyvjLImh1XBzTiDS0jEMwcj3XOGu+uVFs+xsDmP7aZwMuAsAHhYCcTqczRvGlMikY8Nm2TInFpG/2qM0rl5rFZZKgtO9R5bza1tXH9fcsmDEA+M1BFcuB0I4j8lacdX158ejng3Fb8eTLZrThOF2oVnDIDvVOXB/iyI3/qvvYkZ1/Tz0XMnKPazdpS9GxsIXoPWutc/n+ayNkfxd+Sv+R6KdH2bAZVifaANSqhmL6zRxA1Kl5pPsQsSXcmS2jFluX1kgAUIEnkFhkt7BVrKPcNTXuN/ed8hmqKT5ZbT2R6vS10o0Zufu5b1Z3XbaYW+73rWjqXE1c7Vx/AAbhyWWxWsB2RHdIqK6Z7/JRHNUti0sVxNuv6fCxraisj2tpvIrU055fipNjcMTwDWlK++qqL0jx2hsj/AAxUEQrq8mr3npRoHR3JZdnLRjkm5Efm5elqWtI4NP6WXyIi3MgiIgCIiAIiIAiIgMNr8Dui4tf1q/Z2tAae8acPug1zpX3cV2m2eB3Rczvq7bPa4zHJlpm2gIIw56LmzpNo6fjujmN7WlsstRQltagGjgSXGlNeHkvNhvl8eUhL46EOBqXNG9zTqaDUHhkrW+dgnN/4UrZMtHANdUE76fMLX32S1Q5SQPI0rm7X2mVFOp96xUTrcotGxNud4NWEFpzB5HRXt32Yxip1WW6bIY4YmHVrGtI4EACnuUm0AYD0p5qKMbNSvLaUEUpmSQKE50pTOmfuHHitl9Hl6PdE6KQ0fEcTR94RvNQD0NRThhWuG7AxtQauAoCB3ugAFBXPepNxRvinbOe4PC5gOIlpyNTuGhoK5gKKaexvJxcKs6S9jZM64XcRoeo+uqwmOVm4kcWGv8pz/NYca9tl5n3Ej8lDkn9kc6i1wz7+28SAeDmgH8Qs8do9po8l9Dq6knrQ/JRZ5KGga34QqSjFb7l029iS+1s3yV5D+ywutvqMP7z+6PLU+SjGc8fLL8lHntjGglzgKa140qB1puWLl4Rqo+SRKXP8by4eqO6z30zcvEkgaMyGgdAB0CgPtzzXs2fxOrTLI5bzUEUrVTLPcRl70hLWGviOgcO8Bvdq7PQg51oFCjKbLOSiiMJXzEtjDgK4cWYLjQ1wim4/l71sdz3OWaMxEHOpaGNdqan7xHBrSBosJtsFmbSOld7sq569EuW8XCESMcaySzYmksLQe1cGnC8gjTcRvNCV2YMEb3OXNllWxYW+wWmocGtcK54H1I9zmtr7l52FzdOeJbTzes1kvOR0jWSvawOLqFmAGjdMVXOoDxG+mea+bDx0Y7o3/uXQ8ajNNezBTbg0zaERF0GIREQBERAEREAREQGG2eB3RcdMjhv/ABHBvtrsVs8Dui5SSNc8s9/qim/jT89VyfJVtHTgdJlTbLW6v1xd7RWNtvcOKs+x5V71Tm4ClX1yDuG7dz1R1n0yOIOB1eRRrozvdyk3fe6UxUfZq5eiA28j9e79R5r1/iAOqmNsdaUY/wC7vcSKDOjuBLmGm/BmhsMuFwax4rpk45UNGkkim7jpvoClPyP6KiRtTkVngc1vMq1N3y5hrHiuLMmmZZOxp7zjSnaNPVtdV7fdjs6Nw94YcUwNBiGtHa0y59c1LTrki/R9ue2dowjezI9D4T8vcp9TwKiWeDAM3RCuGuBzw44GYW94aZ4DlrQk1JUqa2jCKSOqC6tC92RrQ1JFaUyFKVpuJCiUPaCl6JMTzwPkVgtddaFQbO/C4kNeavc6uJ1cyAMya5HThU8VOdbZjiLWlrnNa2o17obQ4sWRqTXLRS4pqrCbW9GFkL3eFrjzoaeei+Ou5gdjlLQRlpU/pXOm/fxWSSOZ5rVwzJ8RrT7X71dcJjB49mBuBHr/AAuR2IEnP2nHRzqNNTmCHDPkoWKC7kucmYnXtDF4G4jxOZ924KFaL2ml0qB9fofJWsFyPpqQf3naEN0zoKGu47gp1lut4dVxOEA0GJxz71KitCKE89FZxdUmiqkvBq8djcc3VKn2SB/YVZHE/C6RpxiSte1dhp2YqR3nVrplTetsFm+s+PVRRZcDi7AHtrjAo3Gx5IJLcZANTn4hSm9Xw1GW5XLclsUtiJLiTDADGxz3d2cubgGQ+0GEk1bqTlXIra9j29w9G/NVtpo4OayPAXDCXvbEMi0tNAxziThy3dVc7NsDQ5o0aGjnlXVbOSc0kYqLUXZdIiLYzCIiAIiIAiIgCIiAw2wdx1OC0b/AJPWd/wDGOA9lb+iznjUi8ZuPBoIuKXPvv+D97lzXv/BJfXk19U8ei3tFToIv1maG24ZN75N253scuS8/5ddvL/J3Dot+RPx0OtI0M7N8nfCfa5c16bs4PVPwdOXJb0ij8eI60jSW7PgfdPwdOXJZG3IB90/D+9y5rckU9BDrM1Rt0j1T8PPosjLuA+6fLpyWzonQRHVZrrbH7B8jwPJZ2wewfI8eiu0U9H2R1GUoYdzfwPLkvjo38P5Tz5K7ROl7HUKB1med/wDKePRYnXe87z8K2RFDwLyT1WawbqefvH4Tz/VWdy2Mx4qmtabqaVVoimOFRdkSytqgiItjMIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgP/2Q==',
            'category' => 'Beverages',
            'sku' => 'BEV-001',
            'price' => 15,

            'quantity' => 42,
            'unit' => 'Kg',
            'last_update' => '2023-06-15'
        ],
        [
            'id' => 2,
            'name' => 'Tuna',
            'image' => 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhUSExMWFhUXFhUbGBgXFxgZGhcVFhcWFhYYGBcaHSghGBolGxUXITEhJSkrMC4uFx8zODMtNygtLisBCgoKDg0OGxAQGy0lICUtLS8vLS0tLS0tKy01LS0tLS4tLS0tLS0tKy0vLS0tLS0tLS0tLS0tLS8tLS0vLS0tLf/AABEIAOEA4QMBEQACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABAUCAwYHAQj/xABLEAACAQIDBAUHCQMJCQEBAAABAgMAEQQSIQUGMUETIlFhcQcyQlKBkaEUYnKCkrHB0dIVI5MWM0ODorLC4fA0RFNUY3Ojs/EkF//EABsBAQADAQEBAQAAAAAAAAAAAAABAgMEBQYH/8QAOREAAgECBAMGBQMDAwUBAAAAAAECAxEEEiExQVFhBRNxgZHwIjKhsdFCweEUI/EGM1IVYnKSoiT/2gAMAwEAAhEDEQA/APcaAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKA+MwGpNvGgIGI23hk86ZB9YE+4VRziuJKi2V02+WEXgzN9FT+Nqq60S3dsgy7+RejC58SB+dV79cie7IUvlAf0YB7WJ+4VHfvkT3ZDl8oOI5RRD7R/Go76Q7tESXyi4scEh+y36qd7IZEQZfKfjR6EH2X/XUqpIjKjUPKrjf+HB9l/wBdWzyGVEvD+U3FnjHD9l/1VV1JDIiyh8oOIPGKP+1+dR3siciJsW/7+lCvsY/jU98+Q7smw79IfOiYeBBqe/6Ed2Tod8MMeOZfEVZVokd2yfBt3DPwlX26ffVlUi+JGVk+OVW1Ug+BBq9ypnQCgFAKAUAoBQCgFAKAhbT2tBh1zTSqg7z+FQ5JbkpNnDbY8rECXWCNpD2nqr+dZupyRZQ5nLYnyh46Y2DCMdiDX31nKcuZZRRoTFzSnrO7nvJNZMuT4NnufRI8dKgklrs+3FlFRcGxcJH6xPgL1INi7PvwjkP1T+VTZ8iLmX7Kc/0De0gfeanKxdGmXYLN/RAfXX86WZF0V8u5mbiLf1qVbUjQ1fyE+l/FSpuyNCVht0in9Gx+uv4GoaZN0TP2IR/RSDw1qtnyJujW2zlXj0i+K1D0JNsWzCeBJ+qfwqcrZGZGxtlSD0b+w0yMnMivx0EiC5ja3baoytE3RWjapQ9V2Q+JFFcgt8JvhjY+Emcdji/x41dVJLiVcEX2A8pS8J4SvzkNx9k61oq3NFXT5HXbK25hsQLwyqx5i9mHip1rVST2KNNFjViBQCgFAKAUB5rv55R+hJgwti/N+Q8P9a93PFzb0RdR5nlkkk+JfPKzOxPE/h2Vm2kaJXJ8Gy1Aux9gqmZsmyLHZ8ClssUJdvC/v5ClmyG0jp8PgJVA6V44R6uhb3CmW27F+RI6SBfSkkPsUfnVfhJ1NsGIJ/msOPEgt8TVlfgiHbizY88486SOPuzKPgKfFxY05ESXGJ6eLv8ARDH7yKW6k+Ro+U4c+nM/gB/nUWRF2MsZ4QYhv9fRqcq5C/UHDqf93xC9/H4FanL0Iv1MDs25srsD6royn7qZRmCbOm7CPHT76nu+YzlhgILEZyx+jIuniAb1KgiHJlpLMFGik+9vvrQoaP23biCKXJMxtk8dPeKrnJsQtqY9pUsoGblxqb3IKLFTqF/ehL6aDjfl4VSSRaLZXyQxnTVT3aVkXIk+z29F7+NTcFVKZYzmF1I4MpsfeKlO4O73J8pTZlgxhuCQFl5g8s/b41vGbW5m432PWFYEAg3B4HtFbGZ9oBQCgKnejElMM5BsTlX7bBT8CapUdosmO5+f12bLJM1xrclieA1N71zZlY3tqWqYYILJr849vcOXtqoLHCbPiXrzkkeqOJ7qsmitmb8TvA4HRwqIU7F0J8W40bYSSPmEwpI6SaTo1PtdvAfnUWRN+RubaaJpBEL+vL1m9g4CpvyFuZ9ZMTKM80/Rp8429yLxp4jwNB+SJ6Mkx7WPRr7h1qaDU+ftUr/Nwwp35Mx97XpcWD7ZxJ/pWHctl+4ClxZGk42c8ZZD9dvzoSWOEidYzKS8jAEhczWNuVXiluZtkLZ82MxJYrMkAHmq4K5u+w195NRcm1iNj91tqtqcTYf9MBgfxpouA8yFhd1pVNpMXMp7VZb/AGWFHLoTbqTZd28WNcPtPX1ZUy38WF6lOJDTJ27uE2p0hTFKjIFuJFYMCb8Bz99W8CpJ2ptfDQAl5BfsBAF+y/M9wuagFDjdpY+ZLwxdDEw0dwRcdw4n2keFLomxF2RA8LiRpDLIDcFwCqn5qkWHjVG77FkjoTvHKdJFV15gov3gaVF2LIwk6OQZoyQeaE8PA8vuqCSIQrCzi/K/BgRyPhUWJuUG09kspuNVPAj8ew1KkS4ntXk+xjtAY3NzEVHhdFYj2Nf310Un8JjPc6mtSgoBQFPvhhOlwc6jQhCw8YyJB7ytvbUSV1YlPU8sglEoy6LIeN9BIQLDXk47OfKuNx1N76H35OQ1iNRwHDWoJNb4cnzuX386ECLDEG9rkcPGlwZTRkm59lLkmUEdje1z93fQg1zKWNzcmoJMBDQAQ1IPpioDJUpcEeH5VC7NC6spNzFJwv8ANblV4ysUcSc22wR++wky9pSzD2ZTf4VN0yLM1w7xYNTo2IjP0ZF++mhOpZDfLDWszSSDvjzfcppdEWZDO9cIJMWFkJ7eiYD+0FtS66E5Tn9p7f2riGaOK+HjPPS9ra6nh7KtmS3ZWzGyNirC4lcmWQc36w7eB0A7hVHK5dI6eXac62ZWyDSwUdW1terwqtxYftZm/nIYpO8pZvtCpzCxB2jCM1wgT5oJNhy1OtQSasJCcwA8KgGUuHOcqBdrC9tbkf5c6A0YnHhBkS0kvdqkZvxJ4Mw7B7aW4sX5Hpnk2wBiwmZjd5HdmJ43By2/s39prrgrIxk9Tq6uVFAKAhbc/wBmn/7Un9w0B5YmAVxfmePYf86yqU82qNIytubo43SysMwHANxA+a/G3vFc0rrc0VnsbfkoYkhyL8m5HuYcvEVGjGobAOuuW/euo+HClmLmsxX150JMkhsb0IDYYHhp3UBpbDGhJgYKA+dFQGJioBkoD6otwuPfQBr9t/EA/fQAFhwt9kflQAu/b8AKAweIk66n30BlHCBqRfuqQZSEtqf/AIKgg+wLrdVzNyAF7ewUQNh2XK2r2X6Zsfs+d8KnxB9jwqx6gs7fZX36kj3VGZImxq/Z8kvUHm80QZV+seLfWJoryegaS3LHD7CSEXIBblbgPzNdMKWXVmUp30R2e5h//Kv0pP77VsZl5QCgFAQduf7NP/2pP7hoDzPZmKQkLfra2B0uFNiR2gHj2VLi1qQpJ7Fh+2sGOq88PgXXT46VbuZyXysjvIriMRNhjE8sMqSFFJyI6uTbkLG9c1bDuKbs0dWGarVI001q7XM9jK88KzxKcrZrC4zDKxU6X7QeFc0YSazI2xVF4eq6U3qrfVXJMjuNHX7a/mKNyW5jZPYxHRnig9hI/wAqZkLDoIvnD3H8qm6Go+TJyk96/kTTQA4VfWQ/aH4U0BicEnan2x+NLIGpsCvrJ/ET86WFzA4Aesn8RP1Uyi58+Q/OT+JH+dLC4Gzx60f8RPwNLAyGz/nxfaJ+4Ut1BkNnjnIg8FY/gKacwZjAR85GPgoH3mo0GpmMLCPRY+LfkKXQ1FoxwjT2jN/evTMLG+NZnFkViPmiw+GlLTew+FELYqrimkWNx+7y57g+lmAtpr5ppThnbsdOJw1XDxjKorZr215W/JZ/s2BCQzF2W1wAdL2tcDUceZ4V0KhFas4u8b2OSx+9h6GeSGMlIzZbOsYK5WYszW6vm6CxJLqOZt5LdV4hQVZpPhZc+Fkv4R6eKwn9LGLkrya1XL39y7w2JZ4AzG5FwTprY6HTTUWr1MLUdSmnLc4cTCManw7OzOk3BxCyYNGXhnmAPbaVxfw0reMlJXRlVpunLLLc6KrGYoBQFVvWxGCxRGhGHmt/DaqTdos1oJOpFPmjwjaMhnCwllSKIZ5pCL2aS5AUcSSGsFHEnurvofClLdvY4aqWZxWiTf3LXdjBwsyAYE9EzKFnmszMR1vMIsAVVvN99Wqykl82vJEU4xb+XTmzsMHJgcQ6xpFC2pI6SCwdVBuYiyWksbcDw1rFqpBXbfk/uaPLKySXvkXG72DdHmduorMBHErXWNFvY5RortfMbdw5VnNppJeppFO7bLTau14MMmedwoPAcSx7FUamsJzjBfEdWGwtXETy0lf7LxZxeK38w7taLAlyTpdgjHwEasSa5HXi9onvQ/09NK9Sql5XX1aNw3ghFjNgcXAvNgrFR4lwNKZ48YtGL7HctKVaEnyvr9LltgmwEy5osWtuYYqpHirWIq6jTktJHn1sFiqMss6b8ldequjZs7Z0WIDtDOHVHKFgpsWAVjY36wsw1FI0lLZmdelVoNKrGzavbjb9tje+7Desp8Qan+nfMw7w0vuo5/4Z9/6ajuJE94jWd0W9WP8A17KdxId4j6u6berH7/8AKncSHeI2puxJ/wBMe0/pp3Eh3iNybtPzdR4An8qn+nfMjvDem7XbJ7l/zq3cdSO8Nybuxc2c+0D8Kt3ESO8ZIj2JAPQv4kn8asqUORGdkqLCRr5qKPBRVlFLZENtmyrEHl25EphfGta/WjA+3Nc+AFz7K4MNJJzfL+T6btv+5Cgl1+0TjtobWllYtnYLc2QMdL62Ivq3aTqdarllN5pHTnwuDj3VOOea3sru/V/sjKCNkjkU5LklcknmgHLeQqRdyGQWUC9+fZlWyxlFK/O6304dL31e1jzKyr4mWeWvC3BdS/x144IcBHcOUUOeaR2vY9+Ua9w7xW+ZqKp8Xq+l9WZ0aUbvES+WOkerWnvr4HoW4KgYKMKLKGkA8BIw99dVGWaCaPLqtubctzoq1MxQCgKvehL4PEixN8PMLC1/5tuF9KhxzKxaE8klLlqeJbBwKuM8gvFGOldfXnkXpAG7QkZQW7T412OTTyx3enlt9Wcjsk5PZa/udo3SGASMLspSTIo4IpuyqOJboyw8ay+HPlXhf31Lwc3DNPfe3IqDM0McbhWKosIRukDJPKkkSxHDrmOTNCJgwAXRtb8a3spN3636LW9/OxTVJW/y+h2268xaDpZCMzNIzkcL3tYfNVQFHcori7yM9Y7cPfXc7Z0JU5ZJb6er4eWx5btnacmLxBk1JZgsa9ik2RB2E3F+8mvKnNzlc+/wmHhhKKhtZXb68X74HsO6m7keDiAABlIHSSW1Y9gPJRyH416FKkoLqfF9oY+pi6l38vBcv55lzNOiKWdlVRxLEADxJrRtLc4oQlN5Yq76HHbc2BgMeGbDSQ9OASGiZSGPZIqnUH1uI+Fc06dOp8rVz3MLjsZgWlXjLJyknp4N/bb7lvuPs5sNgo0kGVzmZgeTOxIB7wLD2VpQjlgkzj7VxCxGKlKGq0S8kdBWx5ooDnt4N7YMM4h1knYqBGva5AXMx0W9+891Y1K0YO27PSwfZdbExdTaCvq+m9lx+3U6GtjzRQHxmA1JtQJX2NGMx0US5pZEjW9ruwUX8SahyUd2aUqNSq8tOLb6K5H2ptvD4fL00qxlvNBOp77DgO/hVZVIx3Zrh8HXxF+6i3b37RA27vhhMK4jkcl9LqgzFQebdnbbj3VSdeEHZnRhOysTio56a05vS/h7sb96NufJcMcQE6TVQBew65ABJ5DX7qtUqZI5jPAYP+qrqk3bf6G7YW0PlGHinK5TIobLe9r9h5ippyzRTMsXQ7itOle9na5yO6uBVpcSG4Z1PjZpND3amuPDRTc0/e56valR93Sa4fhHEbz4U7PkMeUPnJaN2AI6MFbA88ykEW7GBverNOLszTDONeOdN9efH6ciPsPCMo/aGJBOv7lW4yyWsrEeooF787e+kmorM/8ALNZPvJf09LT/AJPkvyyfgc1nle7SS31PJOJP1iOHYtYRbe+7+38/YzxuXSnHSMfv/C+rPTPJ5/sMf0pf/Y9enSVoI8Kv87OkrQyFAKArN6CfkeJtx+TzW8ejapjuiJbaHlmzsEWhVAbKxJY88pNwBy4WHgK0jNRlmfkZVabnHKno9/AtcXtmPD9RM0s7ebEGJYk6AtyjW/M2qYwc9XoufvctdR0V2/UbM3ZWGOaeUK2JkVyxUWWPNxWMch2niazxdZypuMdkvdzbBU8taMnvcu9mRn5DIq8ejnA8SGtXHQ1oep6FaS/rIt7Xj+x55uUgbHYYHh0l/aqs6/FRXNRXxo+t7UbjhKrXL7tJnuM0wRGdtFVSx8FFz8BXpN2Vz4KEHOSit3oeU7G2xFisacTj5FEcYLRRObgMTZFVPSIFybC5Nq8+M1Oeao/I+yxOEqYXCKjhItyejkuXFt8L8Olyfgtky4raYxcMLQQLIjZ2Ux5wgAbKhsTnsRppYm+ulXUHOpmirI56uKp4bAPD1Zqc2mrJ3tfa7/7d/HbTUqfKZEVxAjaZ5WKZ2zkZEzMwVURRZQAuvEm9Z4lWlZu529hSUqGaMFFXtpu7JXu3ve/gdTtmfFPgZJzI+GhSMdEo0ll4KjSvxQMbdVdddTW83NwzXsvqzx8LDDwxcaWVTk38T/THi1Fcbc3pyRD8mEUssOKDTSqjFFDK3WVrMXKlgbEgprVcMnKMtTft6VOlVpNRTau7NaNcL2t1Oe2NgPle0ynSSlRJI3SlgZcsOkb5iLZriPlpesYRz1bXPUxVf+l7PzZVeyWW3w3e6ty3Oy3sws2FwsrJi5QgA1Zi0ryOwQL0h8xACD1QDx1rpqxlCLak/wBzwezqlLE4mMZUo36K0Ukr3txfi7baGHknifoJpWZjnlsLkm+RRc697EfVphU8rZb/AFDKPfQhFLRcOr9+pSGZsZtoLmLRRzXC3OUCAakLw1kX+1WV+8rdL/Y9DJHCdlZrWlKO/H4uvg/oRPKThAuJjVpJJXZSz3torOVVI0GiiynTmdTeq4iPxJN3Nuw6rlh5OMVFJ2Xildtvjv5cDsYtykmZcRi2ZpiwZlDDo1UebCBbVF08Tc87V0qgpfFPf3oeG+150Yujh0lC1k7a34y8X9NORz/lP2HFDHDJGtiZJA7HVnaQZ7ux1Y9RuPbWOJpqKTR6fYOMqVak4TfBWXBJaWS4blnj3OMweBwanrTxwvIR6EMSqXbxz5QO+ryeeEYc7HHRSwmKr4l7QckusndJel2ztcNAsaqiCyqAqgclUWA9wrqSSVkeBUnKcnKTu3qzl92o7Sz95/xNXDhPnn75np9oyvTp++CNu3dj4aZklxChhCHIzHqjNlLFhztkHHSuucIvWXA4qNarBOFP9VvE4PF4kY3EF20hjFlHzdbX7M2UnwFq86pPO8724e/fI9uP/wCSn3MNZvVvl74ept2/HLlXo1F2NuzKANL9mg+Aolfc5abh8WZ7L1fv9z0LcRbYKMDgDJ8JGFelT+U8mprJl/VygoBQFfvEAcJiAeHQS/3GqUDyXAYTpY1kmdwhClY0cqoBtbMU1djcaXtrYDmdM2V2iteZm7WvJlbjlw15Ew+a0ds1sojDE2y6LmkbRtSdLcTXLjqNR0+8nJ9Eev2RiYKsqMIpc3xf1Oy3U22MQhgkP70KRc+mtrX+kOfv8MKNXvYuEt/uaY/BvDzVWC+G/p/HL0L3d9suaJuIJNvgw+HxquDna9N7+7nNi1mtUR5rioWwGO4G0Uquvzor3AHit18Qayku7qeB9hSmsdg//JWfSX+dfA9lx0YxGGkVGBEsLBWHAiRCFPhrXoy+KOnE+JoydCvGU18sldeDPK9ytups+eVcSjLmAVtOsjIT6PGxzHUdg4ivPo1FTk8x9j2pgpY+jGVBp21XJp9eatx6npextutimvFA4gsf3snUzHl0aalh3m3trthUzvRacz5XE4KOGjac1n/4rW3i+HhqedoBjNta6p0x8MmHFvcTGPtVx/7lbz+x9M74TsrTfL9Zfur/AEOi8rePywRQDjI5Y/RjA/xMh9lbYuXwqPM8z/TlDNWlVf6Vbzf8JjdbaUOH2Y4jcNKkDzSBdcruCVViNAw6ote/VpSlGNJ23tcdoYerXx6zq0XJRV+KW7XTjfbU5/yaYyDDvNNNIFIREReLuWJLBEGrG6pw7axw8oxbbPT7dpVq8YU6Ubq7bfBW2u9lu9y68ruNIjghHB2Zz9QBQP8AyX9la4uWiRwf6bo3nUqPgkvX/BlsnbSw7PjgwpV5hCZJGGqQXBeR5CPSBJAXiSKQqKNNRjvb0K4nCSq42VXEJqGayXGfBJdHxe1ig8meLhinkkkY5yqxxqAWdzI12so1Nsi3PK9ZYZxjK7PS7dpVatGMYLRNtvZKy0183YkYtxituqvFUlUDww6l2/tq3vqX8dfz+xlTi8N2O3xcb/8As7fZo9Yr0D444/yqIDgST6MsZHiSV+5jXNil8B7f+n21jLLin+f2NW4sEeHULM//AOl1RSCGtEgH7uEvbKrda5Um5Lc9KtQpuMbvcy7Xxka9Vxp/Km/Nvd/jodZjJwiM3YNO88hV6tRU4OTPMpwzyUSl2DhyA7n0iB7r3PvPwrkwEXlcnxOvHVLtRXA5PfLbRnlXBQm4JPSMOFl87X1F4ntNh46VpZv/ABW/XoXoLuFm/W9v+1c/F8OS1NhwCJ/NoFuRddbsbALe+nIX5ad9cclKUk36F4tJP7kfGsFQ5jqe/n3dvjV1KOq5Gd80tOB2e4V/kMV+2X3dLJb4V6FL5Eclb52dBWhkKAUBB28mbDTr2wyj3owogeObWxRiwjkGzLovg5yqR4BuPatb0Y5poyraQ8Dk9jSBc0bHJmZDroDkzqV7iVkaxPMCurExU6Tsr6Pb30M8HPu68Xe2q1e3X6FvGzIwYXVhYg8CDyIr5F3i+TP0NZKkbaNPzR3mwNvCcgMQs49gktzXsbtXny7K1cs7Ul833/noeJisE6CeXWH28enX1LHeXYi46MWITEIDkJ81hzRu4/A+2uhVFXVnpL7mWAxcsFN8YPdcV1XvX0Oc3c3on2e3yXFRv0YOinz47nUprZ0v2HtseVTTqypfDJHsY3s2lj49/h5K/Pg/Hk/bXE7uPevZ0gDmeHuz9Vh7GFxXT31N8T599mY6DyqEvLVfTQrcfvwJG6DZ8ZxEx9IgiNB6zE2JHfoO/kaSxF9Kauzqo9jOnHvcY8kFw/U+i936FrNFFhOiMOCV5ZHCEQRopF1LO7O1gEAXix1uBqSBW0YRjsjy62Jq1dJTk11bZz+0dqYPaGLbByYPEyT4YEsFaNQocRkjOJwDfMml76HsNRUpRn8xphMfXwt+6dr76J/c2Y7ePZ2HwI6WCWHCyvLCR0epdWkRwQjFrnonObu41Pdxy5baFHi6zrKs5Xktbv39Cx2TsPB4SP5SmGkzAE3cZ5FW2pAJ6unZrVYUYQ1SN8V2nicSss5aclovO2/mV282NwGJwkeOxEeI+TqMyyKpBySZdSt82Vurrbv4VNSlGe5TB9oVsJfumteauW+wRgpMDfBxiSCRCCiWDPcZWVy7Dr8QcxB0qVTillSM6mMr1Kqqzk3Jap8vBbGjcXD4RozPhsI8IJZQ8uUuwVirZT0jsFuvOwNgRcWNRClCHyovicfiMSrVZ3XLZei0Md1dv4KfF4rD4aJVaHIzSBVHTGTNmZTxYAgdY8cwI0sTZQitkYVK9WokpybS2u9i/wBrbUiw0ZlmcKo95PIKOJPdSc1BXZbD4apiJqnTV373OU2FHJtKZcZOuXDRE/J4j6Tj+lbtI5d/DhdueCdWWeWy2R7GLlT7PpPDUnepL55cl/xXvx6WA3dWOcztIMudmtrc3lE4W17aSKDmGpAse2t6lSMFeR4UYuTsibIGnbsUfD8zXmvPip22ivfqdqy0I9ff0OO3931WBDBhjdj1My6ktwyR21J11YeA14daaayQ2XH9l+7JVJ0v7lX5nqk+HV/svXTR0mwNizYcglc+JkGaUjhEgIKxjW3nG511I55axn/cuo7R+rN6MIqEqlV6vbm77nSYtHyZS65zoW4AczlUcTb/AEKyntlb197GcHHNdJ25fnoc7tPFRxgAAuwAUE2J7OqOAJv461SMop2gvMtGg/ik3vqejbif7DD/AFn/ALXr1KXyI86r87L+tDMUAoDVilujDtBHvFqA8G27HIcHMWv1HGU9o6UXt3LoPYa6qFlUS97GFa7g/fErMfGJnLM7kEsAALtdI0bKhJsAxkHtGnGubCyeHpqEYxW1+Cs5NXel7pRflvorkVYqpK7b4+Oy28bmG2g8EzdHIcrl2AUkKvXcFSvA2I7LV09nTjicOlUjrFJO9nf4U7+dzOq50Kl6cmr3ejtxZns7aOchGsHJ6rDQE8gQNAewjnbTnXNj+yY5XUo6W4fg93svt6edUsS7p6ZuXjzR3mwd67WTE3I5SgXI+mPS8Rr414SmpfP6/n8ntYrsz9VD/wBfxy8NvA7Z44p4x0iRzxHzSQHH1W7fjXUqkor41mXP+TxFKdGbyNwl6eqI0W52zWN/k4v2Z5LfZzWreEaE9jZ9rY+Ktn+i+9i/wGz4YVyxRpGvYqgX7zbia6YxUdkedWr1K0s1STb6syxmKWJC7ZrD1VZz7FUEn3VYyPOPI5EzSY/Fzo0c+InJ6ORWR1iF3BAYDS8uW/zBQGHlkQmfZplVhg0nzTuFJVTnjtnt5oydJqe00B0229uw4qB8NgpknlnHR5oGDiFZOq8sjrcRhULMLkXIAFyRQGrePaGGE+C2f0kar0qvIhYWWPDpnhU66EyiGwPEK1qA5PbOzcVsTEPNgEaTB4q6mAXtDiGGWMr6q5iLHhbqn0LCTpX1WHZGGdkVIlWWbo3ZckQCmFWFgXexzENoobUMRYQUmG2diMNt75QsUkkMkAjmkjgdEVgoCgKbhgBDCLqSOsew0B6BtDY2GlcSzRI7KLLn6wAuToh6t7nja/DsFZTjT+aZ1UcXiKUHTpSaT5afXf62NpxIACxroNBpYAdwFc88Vwpr34FVTbeabIeNdI1MuIkCr3nU9wA4nuFZOl+us/fvkbUlOo+7oRu/fvU4PeTfBpgYobxQ63PBnHO/qr3c+fZWbrOq1Tp6I9qlgaeDpuvX+KS25X4eL68OHMq91dis7HHSKOAXDofQUgN0p5KSLZTx6xPZV601GPdwPKjepU7ypu9S6xGMMfUisZH0Le+1jyUa61zKbSyx06nZGipvNPZcDmcdjzHGTISvXYqbMwcgKptwKnTQ89eyojC9rG88sJeS8jeWDKJbEBVyx5uJNrvIb1pShlTb3Z5kFK7ct3r5cPfI9L8nrXwEP9Z/7Hr1aXyI4a3+4zo60MhQCgNc/mmgPKNrqhmmwb9Uyq7Rnkwa+a3zla5t2WPbUxnlkmJRzRscbgtlylUEbiFlB6UlnXr52jNzexy8OqNA2vHTumqU/wDcipcrpPTc41GX6Xb3Y2DZUlgrsJrmULGC388FdgCdGOqG4086rx7uMs0VbbXoUcZWtJ339TLE7rZc0pkHQDK2ZQSeidnAKm1mICg6cb6cK1jXvZW1KSo7u+hKmPWv22PjmAPDlxr43FRUa04rmz9LwE3PDU5S3cV9idsfac8LjoHILEDLxVidACp0Pjx76xjVlTu0/wAGmJw1GtH+6tuPFeZ2uz984iejxMZhcGxK3ZL9485fj410Qr0qiu9Oq1X5PCrdk1Es9CWZcno/w/p4HVYLFLIuaKRZF7VIb/5XVB1Erwd16nkVabg8tSLT6qxKEx5itViWvmRi4cmZiQVoq8HxIysyzCtFOL4kWPigDhYVN0QfbiozLmD4ZB21V1oLiTlZgZuwVlLExWyLKBgWc8NKpnrT2Vi1orcrto7Rw8Gs8yqfVvdj4KLn4VlKEI61Zfk6aNCvW/2oN9eHrscrtTf+11wsVvnycfYoP3n2VlLFxjpSjbqz2MP2HfWvLyX5/HqcbjsdLM2eV2du0nh3AcAO4VxynKbvJ3PcpUadGOWmrL36kHE4SWZWihXNI4CgD5zAEk8gADc8heu7BJJOTPE7bqO8Ief7HebTnyFYb8lzZebWFyL8gALX4aVzzkszSOWjB5FJlbhsD0zdKxKxqTw4seBVSOXIn2ceCEbrNLY0nWdP4Y7+/aNuOKy5lVF6pXMbAAAHQk9gt8D2VZNyba8zFRyWcnveyKTeLGC4UcMi2HPKQCAR6zEi47q2inJ2Rm2oQcpe3/HA9V3Qw5jwsUZ4qov9K12+JNenFWVjypPM2y6qSooBQHxhpQHmflK2AZVzLo6HMjDQhh3jh/rsqGrkpnlWIxLSyZpT0cwsGa1szLwZrea1rajQ2B059OGxSisk9uZzYig288ESY8HiQuVDdSb3Vl1NiuraMRZmFr21PbXqJRl8S1PNddRdm2vuW27W72IkZkAupQ51GUtk0JUMdELZQtwdeHhWvNU4Z3w2XNk4effVFSg7X3fCK4s3TZszZhZsxuLWsb6i3KvhZtuTb3P1mlGMYRUNklbw4Fvu1hbuZiMwiBOUasWt1Rb3+6uLFT0yczDG1LRVPbNx4W4h1AhlmmX95K9kB0K21ZhzFuHsA50TeeMIPRLUmLbqxp038MVdlWjvG1wWRhzBKsPaNa6U+KOtxjUjZ2a9UdG+8ePwzBGlD9VWs4DWvyJ0a97860pY2pJXTuuqPLXZ+DxCcoxtrbTT+PoToPKJIPPw6N9F2T4ENWyxXOK9bfk559gwfyza8Un+CfF5QofShlHgUb7yKv8A1FPk/oc8uwqv6Zr6r8m8b/YT1Jh9VP11Pf0uvovyZ/8AQ8Tzj6v8Bt/8L6k32U/XTv6XX6Bdh4nnH1f4NmI3uKxmQYV7AXs7qrZfWyjMQKx/r6GbLFN++aKQ7KvPI6i8k2r8r6FDifKFOf5uKNPHM59+n3Vd4yX6YpfU9KHYNFfPJv0X5K3E7YxmJYIMQzZlBIX92q+sGta4Haa5qmLqNNzbS98jqhhMLh4uTppWfHVv/JGwmy1ZGYtmYyqi5T1WNgzkkjhlJ17jXLOq1KyXC79+JrUxMlJJKys277rgvqRNqwCOaRF0AbTw4j760oycoKTN8PNzpRk97EWtDUssVhp8Ci4ljlLXRhzjDj92znkc3Lldeeg6sPKMpSoN/Fv6cPHofNdo4mE6sZxV0tL8/Dp14mOzTNjpGuDDAlule9mYW8xG7xzHAW5kXv3OS7kY9+nFKBZbZ20qJljASJBZQNNBw9lZym5uyL06KjrLcqYcb0cDdJYmU5iBoQoHURvbckd9uddEKTay8NzmrV0p5lutF+5hu7gXxOIEr6gG47z2+yu6lTUUedUqOb1PatnRZUArUyJVAKAUAoCDtLBCRSDQHku+e5xuXUWPaKhxTJTscRDPNh310seYDKfEEWNUjOdP5W0J06dT50n4nebu+URUASXDqB2wgL7Sh0v7aSrSk7y1EKMYK0EkjocZidmbQF+mWOa1gzdRu4MGsHHt8DWFalTq9HzPQwePrYV2WseX45FFtTY2Kw8RTLmiL5+ljuwNhYXtqo568+deVVwc4TztX0t0Po8NjMNiZqadpWtlf7czLZ+0lJFipdI41QymwuWvMbnnwA52FefUpO3Rt7fQmrh2lrezbvl/+SVFiIXxAys5CK2YkBlZVJc9Ym5FzYae2s3GcaeqWv04GUoVIUfiSV2rcGnttt1ZQ47GNO98ouTYWGpvooJ58hXXTpqlG1z0aVKNGFr6fTqb5disMgDqxZ8hAvZWtc6+kBzI51RYhO7a2VzKOLTu2mklfy/a/A0zbJlVkUqLuSFsQdQbG/Zarxrwab5GkcTTkm09iTiNnrHhy5KszuoRlvwF81rgXBsdeHCs41XOrZaJLUyhXlUrZVoktV9iHsydEkDOL2BtpcB7dUkcwDyrWrFyjZe0bV4SnDLF/wCOJJiEjSK3SZw8iK7AnW7AhWBAI4cLW07qo3FRataydjOTgoOOWzSbS8t17uT9oRxfvDIqp+/AS3nMue0jNzy2v3dlY03PTK76a+mnmc1GVT4VBt/DryvbS3UYp1D4kM6RmTKEI63UUgNol7ZlGnbSKbjCybtv4+fIQUnCm4pvLe/DXhvyZDhxAKmCN1SM+c8mjG4s7L2AgAZezxNayjZ55K75Lb31N5U3mVSUW5cEtuif3uS32NPjJmeGM9GbWd+qpAUC9zqeHIGunC4Wq4JW/HvwMVjKOEpKNWWvJav34nR7P2FDhNbiSfm5HVj+gPW7+PhwqmLxEMP8FN3nxfCPh1+x5dbG1cVo/hhy4vx6dCj3txLOpgAzKy9fvuTpc+F/dUdl4e392S1vp+TnnKFrSZxGztnTw3BxORL+YOtcd4Og+Ne9PLNWaOCM3B3iyZLjFHmi57W1N+7s9lUhRS2RM8ROS1ZJ2ZsaXEMCQbV0xhY5nI9S3c2CsSjSrlTpFFAfaAUAoBQCgIuLwSuLEUBxe39zEkvZaA862vuVLGSUuO7iKo4IspFG8U8WjoT3jWs3TZZSJmztvPGepI8Z+azL77GqWaLXTLB9tGTVyrHtyqG9rAAn21lOjGW6O2jj69HSEnbk9V9TZDibahiD3G2h5VhLCQZ2rtmrtOMWbsNMVYOrWKm4rOeDzK1zd9sxnFxnDR8n/BYx7Vk6htGTGWycQFzCxGUGx7q532bvZ77+7FP6/DO6+JX32f1PuExrqFDKr5ekAOcg2k1fhzvz7zUTwEm207bfTY1njsNJtqTV7cOWx8xGJlkUq6IRmuutgnVC2AB4WA0pHAyi7x/yXhjsJB3jJrnpvx5bkeDBn0kvrxDgHw1BHwrR4arwNpdrYf8ATP8A+X/BZ4TqlAqKiB1Z7vnZspuutrADsrKWBqyTbd3ay4HJU7RotNuTbs0tLJXI8my1Z2ZplXMzHRSx1JPMrXTDByUUmy3/AFunCKjGLdl0X5JEOz8GvnvK/cMiD/EfjXRHCQ4tv6HNU7crP5Iper/BPw+1sJBrFhowR6Tkufe3D2VtCnTh8sfXU8+rjcRV0nN26aL6GON36lIIDKv0R+JvWkpSkrHIkkc5i95GPpH31hTw1KHyxS8jSVRvdlc+0JH82/sroULmbkSMHsSeU8CK0VPmUcjr9ibk2sXF6ulYqdzs7ZCRjQVILMC1AfaAUAoBQCgFAKA+Fb0BFxGARuIoCmxu6sb+iKA53H+TlX9EH3UsTcosT5K5PQBHg4/E1XKhchP5MsePN+LJ+oVXu0TmMP8A+f7UHBFP10H+Ko7snOZDcraw/oAf62P9VR3ZOczG6W1h/u3/AJYv11HdjMZfyX2t/wAqf4sP66d2xmH8mdr/APKn+LD+undjMfP5L7X/AOWP8WH9dTkYzIfyS2uf93/8sX66ZGMyPn8itrHjEB/WJ+dTkIzGaeT7aJ85QPrJ+qp7sjMSoPJriT59/tL+Bq2RDMW+D8nNvOHxB/GpsiLnQYHdCNPRFSQXeG2WicAKAmqgFAZUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAf/9k=',
            'category' => 'Canned Goods',
            'sku' => 'CNG-002',
            'price' => 20,
            'quantity' => 3,
            'unit' => 'Kg',
            'last_update' => '2023-07-01'
        ],
        [
            'id' => 3,
            'name' => 'Del monte spaghetti',
            'image' => 'https://lameats.com.ph/wp-content/uploads/2022/05/Del-Monte-Spaghetti-900g.png',
            'category' => 'Pasta',
            'sku' => 'PST-003',
            'price' => 140,
            'quantity' => 18,
            'unit' => 'Boxes',
            'last_update' => '2023-06-25'
        ],
        [
            'id' => 4,
            'name' => 'Bottled Water',
            'image' => 'https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcSuXze2GVj00tPwZQMDsU1d1kXfhomeps0MNI39yLgWAOlquiLedhKgWffiqxwNCSOLZ8DfO3gjWV1V-U7UF4a7qUQlMUT37o_UnqsioJm-ANSCPrIohpQcuQ',
            'category' => 'Beverages',
            'sku' => 'BEV-004',
            'price' => 10,
            'quantity' => 120,
            'unit' => 'Pieces',
            'last_update' => '2023-07-05'
        ],
        [
            'id' => 5,
            'name' => 'Iced Tea',
            'image' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSaxrsMjGIsLdlJL-Z2g2DJYopl3KSUlp3UCQ&s',
            'category' => 'Beverages',
            'sku' => 'BEV-005',
            'price' => 30,
            'quantity' => 25,
            'unit' => 'Boxes',
            'last_update' => '2023-06-30'
        ],
        
    ];
}

/**
 * Get categories
 * 
 * @return array List of categories
 */
function getCategories() {
    // In real application, fetch from database
    return [
        ['id' => 1, 'name' => 'Beverages'],
        ['id' => 2, 'name' => 'Grains'],
        ['id' => 3, 'name' => 'Stationery'],
        ['id' => 4, 'name' => 'Baking'],
        ['id' => 5, 'name' => 'Canned Goods'],
        ['id' => 6, 'name' => 'Cleaning Supplies'],
        ['id' => 7, 'name' => 'Dairy'],
        ['id' => 8, 'name' => 'Produce']
    ];
}

/**
 * Add new product
 * 
 * @param array $data Product data
 * @return array Success status and message
 */
function addProduct($data) {
    // In real application, insert into database
    // Just simulation in this version
    
    // Validate required fields
    $requiredFields = ['name', 'sku', 'category_id', 'price', 'quantity'];
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || empty($data[$field])) {
            return ['success' => false, 'message' => "Field '{$field}' is required"];
        }
    }
    
    // Check if SKU exists (would query database in real app)
    $existingSKUs = ['BEV-001', 'GRN-002', 'STA-003', 'BEV-004', 'BEV-005', 'BAK-006'];
    if (in_array($data['sku'], $existingSKUs)) {
        return ['success' => false, 'message' => "Product with SKU '{$data['sku']}' already exists"];
    }
    
    // In real app, we would insert the product into database here
    
    return ['success' => true, 'message' => 'Product added successfully'];
}
?>
