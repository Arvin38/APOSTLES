<?php
use PHPUnit\Framework\TestCase;

class InventoryTest extends TestCase
{
    /**
     * Test that product can be added to inventory
     */
    public function testProductCanBeAdded()
    {
        // Create a new product
        $product = [
            'name' => 'Test Product',
            'sku' => 'TST-001',
            'category' => 'Grains',
            'buyingPrice' => 100.00,
            'expiryDate' => '2025-12-31',
            'quantity' => 10,
            'unit' => 'kg'
        ];
        
        // In a real test, this would interact with your data layer
        // For now, we'll just assert that the product array has expected values
        $this->assertEquals('Test Product', $product['name']);
        $this->assertEquals('TST-001', $product['sku']);
        $this->assertEquals('Grains', $product['category']);
    }
    
    /**
     * Test that product can be deleted from inventory
     */
    public function testProductCanBeDeleted()
    {
        // Set up an array of products
        $products = [
            [
                'id' => 1,
                'name' => 'Rice',
                'sku' => 'GRN-001'
            ],
            [
                'id' => 2,
                'name' => 'Cooking Oil',
                'sku' => 'OIL-002'
            ]
        ];
        
        // Remove a product
        $productIdToDelete = 1;
        $products = array_filter($products, function($product) use ($productIdToDelete) {
            return $product['id'] != $productIdToDelete;
        });
        
        // Assert that the product was removed
        $this->assertCount(1, $products);
        $this->assertEquals('Cooking Oil', reset($products)['name']);
    }
    
    /**
     * Test product can be updated
     */
    public function testProductCanBeUpdated()
    {
        // Set up a product
        $product = [
            'id' => 1,
            'name' => 'Rice',
            'sku' => 'GRN-001',
            'category' => 'Grains',
            'buyingPrice' => 45.00,
            'expiryDate' => '2025-12-31',
            'quantity' => 10,
            'unit' => 'kg'
        ];
        
        // Update the product
        $product['name'] = 'Premium Rice';
        $product['buyingPrice'] = 55.00;
        $product['quantity'] = 15;
        
        // Assert that the product was updated
        $this->assertEquals('Premium Rice', $product['name']);
        $this->assertEquals(55.00, $product['buyingPrice']);
        $this->assertEquals(15, $product['quantity']);
    }
    
    /**
     * Test notification system updates correctly
     */
    public function testNotificationSystemUpdates()
    {
        // Set up a notification counter
        $notificationCount = 0;
        
        // Simulate adding a product which triggers a notification
        $notificationCount++;
        
        // Assert notification count increased
        $this->assertEquals(1, $notificationCount);
        
        // Simulate updating a product which triggers a notification
        $notificationCount++;
        
        // Assert notification count increased again
        $this->assertEquals(2, $notificationCount);
    }
    
    /**
     * Test stock status updates correctly
     */
    public function testStockStatusCalculation()
    {
        // Test in stock (quantity > 10)
        $this->assertEquals('In Stock', $this->getStockStatus(20));
        
        // Test low stock (0 < quantity <= 10)
        $this->assertEquals('Low Stock', $this->getStockStatus(5));
        
        // Test out of stock (quantity = 0)
        $this->assertEquals('Out of Stock', $this->getStockStatus(0));
    }
    
    /**
     * Helper method to determine stock status
     */
    private function getStockStatus($quantity)
    {
        if ($quantity > 10) {
            return 'In Stock';
        } else if ($quantity > 0) {
            return 'Low Stock';
        } else {
            return 'Out of Stock';
        }
    }
}